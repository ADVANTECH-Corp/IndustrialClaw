# arxiv-ai-agent

## Skills

- `arxiv-fulltext-review`: Collect the latest arXiv title/link/category records with bounded retries and independent source verification.
- `frontend-design`: Anthropic design guidance, applied to the report renderer; includes browser-based responsive checks.

Read skills/frontend-design/SKILL.md before the report-generation step. The reviewed design is implemented in skills/frontend-design/scripts/design.py, not dynamically reinvented on each run. Preserve real data and partial-result disclosures. Follow Task commands exactly.
