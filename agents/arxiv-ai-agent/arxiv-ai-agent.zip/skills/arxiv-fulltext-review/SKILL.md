---
name: arxiv-fulltext-review
description: Collect the latest 30 arXiv title/link/category records with bounded retries, honest partial reports and source verification; render using frontend-design.
permissions:
  - network
  - file_read
  - file_write
---

# arXiv title index

1. Read `skills/frontend-design/SKILL.md` and `skills/frontend-design/DESIGN.md` before generation. The collector imports that Skill's reviewed renderer directly, with no old-template fallback.
2. Run regression tests: `python3 -u skills/arxiv-fulltext-review/scripts/latest.py selftest`.
3. Collect and render: `python3 -u skills/arxiv-fulltext-review/scripts/latest.py run --out outputs/arxiv-ai`.
4. Check sources and report: `python3 -u skills/arxiv-fulltext-review/scripts/latest.py verify --out outputs/arxiv-ai`.
5. After the Task's frontend-design browser Step, final-check data: `python3 -u skills/arxiv-fulltext-review/scripts/latest.py verify --out outputs/arxiv-ai --strict`.

Fixed categories: cs.CV, cs.GR, cs.CL, cs.AI, cs.CE, cs.GT, cs.IT, cs.LG, cs.NE, stat.ML. SubmittedDate descending, ten records/request, nine pages maximum, 30 unique records maximum. No PDFs, full text, summaries, external fonts or model calls. Do not recompute paper data in model context.

Socket timeout 20s, response read deadline 60s, total collection budget 600s. Each failed request gets two extra tries, six seconds minimum between requests; respect Retry-After even when skipping a page. A blocking read may overshoot its deadline by up to one socket timeout. Persist each response and partial report. Start a new invocation with empty current records; never mix historical caches. Disclose every skip, shortfall and zero result. Partial results pass only when honestly disclosed and source-consistent; internal errors stop the Task. Strict verification reconstructs papers from hashed raw feeds, validates sorting/dedup, HTML titles/links/categories and the current invocation. Browser checks run separately in frontend-design's declared Playwright runtime.
