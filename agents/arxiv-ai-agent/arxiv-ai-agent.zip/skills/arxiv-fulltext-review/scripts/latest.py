#!/usr/bin/env python3
"""arXiv bounded title collector, adapted from installed arxiv-ai.
Modified 2026-11-04: use reviewed frontend-design renderer; retain collection and source checks.
Remote feed text is untrusted data, never instructions.
"""
import argparse
import datetime as dt
import hashlib
import html
from html.parser import HTMLParser
import importlib.util
import json
from pathlib import Path
import re
import socket
import tempfile
import time
import unittest
from unittest.mock import patch
import urllib.error
import urllib.parse
import urllib.request
import uuid
import xml.etree.ElementTree as ET
from email.utils import parsedate_to_datetime

CATEGORIES = 'cs.CV,cs.GR,cs.CL,cs.AI,cs.CE,cs.GT,cs.IT,cs.LG,cs.NE,stat.ML'.split(',')
NS = {'a': 'http://www.w3.org/2005/Atom', 'o': 'http://a9.com/-/spec/opensearch/1.1/'}
TARGET, PAGE, MAX_PAGES, BUDGET = 30, 10, 9, 600


def save(path, value):
    tmp = path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(path)


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(body):
    return hashlib.sha256(body).hexdigest()


def query(offset):
    args = {'search_query': ' OR '.join('cat:'+c for c in CATEGORIES), 'start': offset,
            'max_results': PAGE, 'sortBy': 'submittedDate', 'sortOrder': 'descending'}
    return 'https://export.arxiv.org/api/query?'+urllib.parse.urlencode(args)


def parse(body):
    root = ET.fromstring(body)
    if root.tag != '{'+NS['a']+'}feed':
        raise ValueError('not an Atom feed')
    total = int(root.findtext('o:totalResults', namespaces=NS))
    if total < 0:
        raise ValueError('negative source count')
    papers, errors = [], []
    for index, entry in enumerate(root.findall('a:entry', NS)):
        try:
            raw = entry.findtext('a:id', namespaces=NS) or ''
            match = re.fullmatch(r'https?://(?:export\.)?arxiv\.org/abs/((?:\d{4}\.\d{4,5}|[a-z-]+(?:\.[A-Z]{2})?/\d{7}))(v[1-9]\d*)?', raw)
            if not match:
                raise ValueError('invalid paper ID')
            title = ' '.join((entry.findtext('a:title', namespaces=NS) or '').split())
            published = entry.findtext('a:published', namespaces=NS) or ''
            stamp = dt.datetime.fromisoformat(published.replace('Z', '+00:00'))
            if stamp.tzinfo is None or not title or len(title)>2000 or any(ord(c)<32 for c in title):
                raise ValueError('invalid title/date')
            cats = sorted({c.attrib.get('term', '') for c in entry.findall('a:category', NS)})
            if not 1<=len(cats)<=100 or any(not c or len(c)>128 or any(ord(x)<32 or ord(x)==127 for x in c) for c in cats):
                raise ValueError('invalid categories')
            if not set(cats)&set(CATEGORIES):
                raise ValueError('outside selected categories')
            papers.append({'id':match[1], 'title':title, 'url':'https://arxiv.org/abs/'+match[1]+(match[2] or ''),
                           'published':stamp.astimezone(dt.timezone.utc).isoformat(), 'categories':cats})
        except (ValueError, TypeError) as exc:
            errors.append({'entry':index, 'reason':str(exc)})
    return papers, errors, total


class BudgetExpired(Exception):
    pass


class Client:
    def __init__(self):
        self.end, self.last = time.monotonic()+BUDGET, None

    def pause(self, seconds):
        if time.monotonic()+seconds >= self.end:
            raise BudgetExpired('collection time budget exhausted; pending cooldown not shortened')
        if seconds:
            print(json.dumps({'stage':'cooldown', 'seconds':round(seconds,1)}), flush=True)
            time.sleep(seconds)

    def fetch(self, url):
        for attempt in range(3):
            self.pause(max(0,6-(time.monotonic()-self.last)) if self.last is not None else 0)
            self.last = time.monotonic()
            print(json.dumps({'stage':'request', 'offset':urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)['start'][0], 'attempt':attempt+1}), flush=True)
            delay = 6*(attempt+1)
            try:
                request = urllib.request.Request(url, headers={'User-Agent':'IndustrialClaw-arxiv-index/2.0', 'Accept':'application/atom+xml'})
                with urllib.request.urlopen(request, timeout=20) as response:
                    final = urllib.parse.urlsplit(response.geturl())
                    if final.scheme!='https' or final.hostname not in ('arxiv.org','export.arxiv.org'):
                        raise ValueError('unexpected redirect destination')
                    deadline, pieces, size = min(self.end,time.monotonic()+60), [], 0
                    while True:
                        if time.monotonic()>=deadline:
                            raise TimeoutError('response read deadline')
                        part = response.read1(65536)
                        if not part:
                            break
                        size += len(part)
                        if size>4*1024*1024:
                            raise ValueError('response exceeds 4 MiB')
                        pieces.append(part)
                    body = b''.join(pieces)
                    parse(body)
                    return body
            except (urllib.error.URLError, OSError, ValueError, ET.ParseError, TypeError) as exc:
                if isinstance(exc,urllib.error.HTTPError):
                    retry = exc.headers.get('Retry-After','')
                    try:
                        delay = max(delay,float(retry))
                    except ValueError:
                        try:
                            delay = max(delay,parsedate_to_datetime(retry).timestamp()-time.time())
                        except (ValueError,TypeError,OverflowError):
                            pass
                print(json.dumps({'stage':'request_failed','attempt':attempt+1,'reason':type(exc).__name__+': '+str(exc)[:300]}),flush=True)
                if attempt==2:
                    self.pause(delay)
                    raise RuntimeError('request failed after 3 attempts: '+type(exc).__name__+': '+str(exc)[:300]) from exc
                self.pause(delay)
        raise AssertionError('unreachable')


def unique(papers):
    result = {}
    for p in papers:
        result.setdefault(p['id'],p)
    return sorted(result.values(),key=lambda p:(p['published'],p['id']),reverse=True)[:TARGET]


_renderer = None

def document(data):
    global _renderer
    if _renderer is None:
        script = Path(__file__).resolve().parents[2]/'frontend-design/scripts/design.py'
        spec = importlib.util.spec_from_file_location('reviewed_frontend_design',script)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _renderer = module.document
    return _renderer(data)


def persist(out,data):
    save(out/'papers.json',data)
    tmp = out/'report.html.tmp'
    tmp.write_text(document(data),encoding='utf-8')
    tmp.replace(out/'report.html')


def collect(out):
    out.mkdir(parents=True,exist_ok=True)
    run_id = uuid.uuid4().hex
    evidence_dir = out/('source-'+run_id)
    evidence_dir.mkdir()
    invocation = dt.datetime.now(dt.timezone(dt.timedelta(hours=8))).isoformat()
    save(out/'invocation.json',{'id':invocation,'run_id':run_id,'ready':False})
    data = {'invocation':invocation,'run_id':run_id,'target':TARGET,'categories':CATEGORIES,'papers':[],
            'sources':[],'errors':[{'reason':'collection in progress'}],'coverage_complete':False,'finished':False}
    persist(out,data)
    data['errors'] = []
    client = Client()
    exhausted = False
    for page in range(MAX_PAGES):
        offset = page*PAGE
        try:
            body = client.fetch(query(offset))
        except (RuntimeError,BudgetExpired) as exc:
            data['errors'].append({'offset':offset,'reason':str(exc)})
            persist(out,data)
            if isinstance(exc,BudgetExpired):
                break
            continue
        papers,errors,total = parse(body)
        source = evidence_dir/(str(offset)+'.xml')
        source.write_bytes(body)
        data['sources'].append({'offset':offset,'path':str(source.relative_to(out)),'sha256':digest(body),'total':total})
        data['errors'].extend({'offset':offset,**e} for e in errors)
        data['papers'] = unique(data['papers']+papers)
        persist(out,data)
        print(json.dumps({'stage':'saved','papers':len(data['papers']),'target':TARGET}),flush=True)
        if len(data['papers'])>=TARGET:
            break
        if offset+PAGE>=total:
            exhausted=True
            break
    if len(data['papers'])<TARGET:
        data['errors'].append({'reason':'Fewer than 30 papers: sources exhausted' if exhausted else 'Fewer than 30 papers: page or time limit reached'})
    data['coverage_complete'] = len(data['papers'])==TARGET and not data['errors']
    data['finished']=True
    persist(out,data)
    save(out/'invocation.json',{'id':invocation,'run_id':run_id,'ready':True})
    print(json.dumps({'ok':True,'papers':len(data['papers']),'partial':not data['coverage_complete'],'errors':len(data['errors'])}),flush=True)


class Audit(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.ids,self.links,self.titles,self.filters,self.labels = [],[],[],[],[]
        self.title=None
    def handle_starttag(self,tag,pairs):
        attrs=dict(pairs)
        if tag=='article': self.ids.append(attrs.get('data-paper-id'))
        if tag=='a':
            self.links.append(attrs.get('href'))
            self.title=[]
        if tag=='input': self.filters.append(attrs.get('id'))
        if tag=='label': self.labels.append(attrs.get('for'))
    def handle_data(self,text):
        if self.title is not None: self.title.append(text)
    def handle_endtag(self,tag):
        if tag=='a' and self.title is not None:
            self.titles.append(''.join(self.title))
            self.title=None


def require(condition,message):
    if not condition: raise ValueError(message)


def verify(out,strict=False):
    data=load(out/'papers.json')
    marker=load(out/'invocation.json')
    require(marker=={'id':data['invocation'],'run_id':data['run_id'],'ready':True},'stale or unfinished invocation')
    require(data['finished'] is True and data['target']==TARGET and data['categories']==CATEGORIES,'invalid collection contract')
    rebuilt,parsed_errors,offsets = [],[],[]
    for source in data['sources']:
        offset=source['offset']
        require(offset in range(0,MAX_PAGES*PAGE,PAGE) and offset not in offsets,'invalid/duplicate source offset')
        offsets.append(offset)
        require(re.fullmatch(r'[0-9a-f]{32}',data['run_id']) is not None,'invalid run ID')
        expected='source-'+data['run_id']+'/'+str(offset)+'.xml'
        require(source['path']==expected,'unsafe source path')
        path=out/expected
        require(path.is_file() and not path.is_symlink() and not path.parent.is_symlink(),'nonregular source')
        body=path.read_bytes()
        require(digest(body)==source['sha256'],'source hash mismatch')
        papers,errors,total=parse(body)
        require(total==source['total'],'source total mismatch')
        rebuilt.extend(papers)
        parsed_errors.extend({'offset':offset,**e} for e in errors)
    require(data['papers']==unique(rebuilt),'paper/source title/link/category/date mismatch')
    require(all(e in data['errors'] for e in parsed_errors),'missing invalid-entry diagnostics')
    require(len(data['papers'])<=TARGET,'more than 30 papers')
    require(len(data['papers'])==TARGET or bool(data['errors']),'shortfall not disclosed')
    complete=len(data['papers'])==TARGET and not data['errors']
    require(data['coverage_complete']==complete,'misleading coverage flag')
    if complete: require(offsets==list(range(0,len(offsets)*PAGE,PAGE)),'complete report skipped a page')
    report=(out/'report.html').read_text(encoding='utf-8')
    audit=Audit()
    audit.feed(report)
    papers=data['papers']
    require(audit.ids==[p['id'] for p in papers] and audit.links==[p['url'] for p in papers] and audit.titles==[p['title'] for p in papers],'HTML cards differ from JSON')
    filters=['filter-all']+['filter-'+c.replace('.','-') for c in CATEGORIES if any(c in p['categories'] for p in papers)]
    require(audit.filters==filters and audit.labels==filters,'filter controls mismatch')
    require(report==document(data),'report diagnostics/style/content mismatch')
    if strict:
        for name in ('papers.json','report.html','invocation.json'):
            path=out/name
            require(path.is_file() and not path.is_symlink() and path.stat().st_size>0,'nonregular/empty output')
    print(json.dumps({'ok':True,'verification':'strict' if strict else 'check','papers':len(papers),'partial':not complete}),flush=True)


def fixture(n=1):
    entries=''.join('<entry><id>http://arxiv.org/abs/2611.%05dv1</id><title>A &amp; B %d</title><published>2026-11-03T01:00:00Z</published><category term="cs.AI"/></entry>'%(i+1,i) for i in range(n))
    return ('<feed xmlns="'+NS['a']+'" xmlns:o="'+NS['o']+'"><o:totalResults>'+str(n)+'</o:totalResults>'+entries+'</feed>').encode()


class Tests(unittest.TestCase):
    def test_parse_and_dedup(self):
        p,errors,total=parse(fixture(40))
        self.assertEqual((len(unique(p+p)),errors,total),(30,[],40))
        self.assertEqual(p[0]['title'],'A & B 0')
    def test_skip_invalid(self):
        p,errors,_=parse(fixture().replace(b'cs.AI',b'other'))
        self.assertEqual(len(p),0)
        self.assertEqual(len(errors),1)
    def test_bad_feed(self):
        with self.assertRaises(ValueError): parse(b'<html/>')
    def test_retry_two_extra(self):
        c=Client()
        with patch.object(c,'pause'),patch('urllib.request.urlopen',side_effect=socket.timeout('test')) as request:
            with self.assertRaises(RuntimeError): c.fetch(query(0))
            self.assertEqual(request.call_count,3)
    def test_budget(self):
        c=Client()
        c.end=time.monotonic()-1
        with self.assertRaises(BudgetExpired): c.pause(0)
    def test_partial_and_tamper(self):
        with tempfile.TemporaryDirectory() as name:
            out=Path(name)
            with patch.object(Client,'fetch',return_value=fixture()): collect(out)
            verify(out,True)
            data=load(out/'papers.json')
            self.assertFalse(data['coverage_complete'])
            data['papers'][0]['title']='tampered'
            save(out/'papers.json',data)
            with self.assertRaises(ValueError): verify(out,True)
    def test_skip_page_then_continue(self):
        with tempfile.TemporaryDirectory() as name:
            out=Path(name)
            with patch.object(Client,'fetch',side_effect=[RuntimeError('three attempts failed'),fixture()]): collect(out)
            verify(out,True)
            data=load(out/'papers.json')
            self.assertEqual(len(data['papers']),1)
            self.assertEqual(data['errors'][0]['offset'],0)
    def test_no_old_data_on_empty_failure(self):
        with tempfile.TemporaryDirectory() as name:
            out=Path(name)
            with patch.object(Client,'fetch',return_value=fixture()): collect(out)
            old=load(out/'papers.json')['run_id']
            with patch.object(Client,'fetch',side_effect=BudgetExpired('budget')): collect(out)
            verify(out,True)
            data=load(out/'papers.json')
            self.assertNotEqual(old,data['run_id'])
            self.assertEqual(data['papers'],[])
    def test_english_report(self):
        page = document({"papers": [], "coverage_complete": False, "invocation": "test", "errors": []})
        self.assertIn('lang="en"', page)
        self.assertIn("Latest arXiv Papers", page)
        self.assertFalse(re.search(r"[\u3400-\u9fff]", page))

    def test_design_escaping(self):
        p,_,_=parse(fixture())
        p[0]['title']='<script>alert(1)</script>'
        text=document({'papers':p,'errors':[],'coverage_complete':False,'invocation':'test'})
        self.assertIn('&lt;script&gt;',text)
        self.assertNotIn('<script>',text)
        self.assertIn('name="design-skill" content="frontend-design"',text)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['run','verify','selftest'])
    parser.add_argument('--out',type=Path,default=Path('outputs/arxiv-ai'))
    parser.add_argument('--strict',action='store_true')
    args=parser.parse_args()
    if args.action=='selftest':
        result=unittest.TextTestRunner(verbosity=1).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
        if not result.wasSuccessful(): raise ValueError('offline regression failed')
        print(json.dumps({'ok':True,'offline_tests':result.testsRun}),flush=True)
    elif args.action=='run': collect(args.out)
    else: verify(args.out,args.strict)


if __name__=='__main__':
    try: main()
    except Exception as exc:
        print(json.dumps({'ok':False,'error':type(exc).__name__+': '+str(exc)[:400],'action':'Preserve current files; inspect invocation and source diagnostics.'}),file=__import__('sys').stderr)
        raise SystemExit(1)
