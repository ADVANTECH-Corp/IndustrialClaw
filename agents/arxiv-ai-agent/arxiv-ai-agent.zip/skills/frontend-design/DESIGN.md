# arXiv research reading desk

Subject: ten-category AI paper index, newest submitted date first. Audience: researchers scanning real titles, categories and source links. No summaries or invented marketing copy.

## Reviewed tokens

- Paper #f5f8ff; surface #ffffff; ink #18304d; secondary #485c77; signal #254dcc; rule #c5d1e3.
- Heading: Georgia with Noto Serif CJK TC/serif fallbacks, 32–56px. Titles/body: Noto Sans CJK TC, Arial/sans-serif, 17–21px. No network fonts; actual fallback varies by device. Body width <=74ch.
- Left-aligned reading desk: a short masthead in a blue panel, then a quiet category rail beside spacious paper rows. Rounded containers distinguish page hierarchy, not identical shadow cards.

Desktop: [masthead / scope and freshness] then [category rail | title + category rows].
Mobile: [masthead] then [wrapped category controls] then [single column titles].

## Alternatives and critique before implementation

Rejected old identical white cards: their equal visual weight slows title scanning. Rejected newspaper columns: creates narrow English titles and generic broadsheet styling. Retain one distinctive element, the blue research-desk header. Use paper titles as the actual main content; no oversized count dashboard, numbered decoration, all-caps eyebrows, gradients, animation, external assets or made-up papers.

## Implementation contract

Read official SKILL.md first. Renderer implements these tokens. CSS-only category filtering keeps the report self-contained. Show coverage and exact errors, even zero results; never style missing data as complete. Radio controls remain keyboard-operable with visible focus. Maintain semantic header/main/nav/section/article and a responsive single column at 700px. Keep print view readable. No motion means reduced-motion preferences have nothing to disable.

## Critique and evidence

Runtime browser checks 1440x1000 and 390x844, horizontal overflow, real title/link counts, filtering/restoration, focus visibility and screenshots. Browser evidence is tied to report SHA256 and run ID. Review screenshots for subjective quality; automated measurements alone do not establish beauty. No screenshots or browser checks have been claimed in advance.
