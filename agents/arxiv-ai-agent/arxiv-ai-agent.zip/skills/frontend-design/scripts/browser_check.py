#!/usr/bin/env python3
"""Bounded local-file Chromium checks; screenshots are not subjective approval."""
import argparse
import hashlib
import json
from pathlib import Path
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def verify(out, final=False):
    data = json.loads((out/'papers.json').read_text())
    evidence = json.loads((out/'browser-check.json').read_text())
    require(evidence['ok'] is True and evidence['run_id'] == data['run_id'], 'stale/failed browser evidence')
    require(evidence['report_sha256'] == sha(out/'report.html'), 'report changed after browser check')
    require([v['width'] for v in evidence['views']] == [1440,390], 'missing desktop/mobile checks')
    for view in evidence['views']:
        require(view['papers'] == len(data['papers']) and view['overflow'] is False, 'layout/data check failed')
        for name in ('desktop.png','mobile.png'):
            path = out/name
            require(path.is_file() and not path.is_symlink() and path.stat().st_size > 100, 'missing screenshot')
    for name, digest in evidence['screenshots'].items():
        require(name in ('desktop.png','mobile.png') and sha(out/name) == digest, 'screenshot hash mismatch')
    require(len(evidence['screenshots']) == 2, 'missing screenshot hashes')
    if final:
        # Re-run independent raw-source reconstruction, not collection or rendering.
        import importlib.util
        script = Path(__file__).resolve().parents[2]/'arxiv-fulltext-review/scripts/latest.py'
        spec = importlib.util.spec_from_file_location('source_audit', script)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        module.verify(out, True)
    print(json.dumps({'ok':True,'browser_evidence':'current','final':final}), flush=True)


def run(out):
    from playwright.sync_api import sync_playwright
    data = json.loads((out/'papers.json').read_text())
    report = out/'report.html'
    before = sha(report)
    views = []
    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True)
        try:
            for width, height, name in ((1440,1000,'desktop.png'),(390,844,'mobile.png')):
                page = browser.new_page(viewport={'width':width,'height':height}, reduced_motion='reduce')
                page.set_default_timeout(10000)
                # External paper links are never opened; external requests cannot leak data.
                page.route('**/*', lambda route: route.continue_() if route.request.url.startswith('file:') else route.abort())
                errors = []
                page.on('pageerror', lambda err: errors.append(str(err)))
                page.goto(report.resolve().as_uri(), wait_until='load', timeout=15000)
                require(page.locator('html').get_attribute('lang') == 'zh-Hant', 'missing document language')
                require(page.locator('meta[name="design-skill"]').get_attribute('content') == 'frontend-design', 'wrong renderer')
                require(page.locator('h1').inner_text() == 'arXiv 最新論文', 'missing page heading')
                require(page.locator('article').count() == len(data['papers']), 'browser paper count mismatch')
                require(page.locator('a.paper-url').all_text_contents() == [p['title'] for p in data['papers']], 'browser title mismatch')
                require(page.locator('a.paper-url').evaluate_all('(xs)=>xs.map(x=>x.getAttribute("href"))') == [p['url'] for p in data['papers']], 'browser link mismatch')
                require(not page.evaluate('document.documentElement.scrollWidth>innerWidth+1'), 'horizontal page overflow')
                require(page.locator('h2').evaluate_all('(xs)=>xs.every(x=>x.scrollWidth<=x.clientWidth+1)'), 'title overflow')
                require(page.locator('h2').evaluate_all('(xs)=>xs.every(x=>parseFloat(getComputedStyle(x).fontSize)>=18)'), 'titles too small')
                page.locator('#filter-all').focus()
                outline = page.locator('label[for="filter-all"]').evaluate('(x)=>getComputedStyle(x).outlineStyle')
                require(outline not in ('none','hidden'), 'keyboard focus not visible')
                groups = [c for c in data['categories'] if any(c in p['categories'] for p in data['papers'])]
                for cat in groups:
                    key = cat.replace('.','-')
                    page.locator('label[for="filter-'+key+'"]').click()
                    require(page.locator('.paper-card:visible').count() == sum(cat in p['categories'] for p in data['papers']), 'filter interaction failed')
                page.locator('label[for="filter-all"]').click()
                require(page.locator('.paper-card:visible').count() == len(data['papers']), 'restore-all failed')
                if not data['papers']:
                    require(page.locator('.empty').is_visible(), 'missing empty-state guidance')
                require(not errors, 'browser JavaScript/page error')
                page.locator('h1').click()
                page.screenshot(path=str(out/name), full_page=True, timeout=15000)
                views.append({'width':width,'height':height,'papers':len(data['papers']),'overflow':False,'filters_checked':len(groups),'focus_visible':True})
                page.close()
        finally:
            browser.close()
    require(sha(report) == before, 'report changed during browser validation')
    evidence = {'ok':True,'run_id':data['run_id'],'report_sha256':before,'views':views,
                'screenshots':{n:sha(out/n) for n in ('desktop.png','mobile.png')},
                'scope':'automated browser layout/interaction checks; screenshots require visual review'}
    (out/'browser-check.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2), encoding='utf-8')
    verify(out)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['run','verify','final'])
    parser.add_argument('--out', type=Path, default=Path('outputs/arxiv-ai'))
    args = parser.parse_args()
    if args.action == 'run': run(args.out)
    else: verify(args.out, args.action == 'final')


if __name__ == '__main__':
    try: main()
    except Exception as exc:
        print(json.dumps({'ok':False,'error':str(exc)[:400],'action':'Stop; inspect browser/runtime and preserve report evidence.'}), file=sys.stderr)
        raise SystemExit(1)
