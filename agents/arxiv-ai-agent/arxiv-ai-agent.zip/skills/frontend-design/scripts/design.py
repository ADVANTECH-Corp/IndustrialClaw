"""Reviewed frontend-design renderer. No remote assets or script execution."""
from html import escape as esc
CATEGORIES = 'cs.CV,cs.GR,cs.CL,cs.AI,cs.CE,cs.GT,cs.IT,cs.LG,cs.NE,stat.ML'.split(',')


def document(data):
    import json
    papers = data['papers']
    groups = [c for c in CATEGORIES if any(c in p['categories'] for p in papers)]
    css = '''*{box-sizing:border-box}body{margin:0;background:#f5f8ff;color:#18304d;font:17px/1.65 "Noto Sans CJK TC",Arial,sans-serif}main{max-width:1240px;margin:auto;padding:40px 32px}header{background:#254dcc;color:#fff;border-radius:22px 22px 6px 6px;padding:36px 42px;margin-bottom:30px}h1{font:500 clamp(32px,4vw,56px)/1.15 Georgia,"Noto Serif CJK TC",serif;margin:0 0 18px}header p{max-width:74ch;margin:12px 0}header ul{padding-left:24px;overflow-wrap:anywhere}#coverage{font-weight:700}.reading-desk{position:relative;padding-left:220px;min-height:220px}.filters{position:absolute;left:0;top:0;width:190px;display:flex;flex-direction:column;gap:7px}.filters label{padding:9px 12px;border:1px solid #c5d1e3;border-radius:8px;cursor:pointer;overflow-wrap:anywhere}.domain-radio{position:absolute;opacity:0;width:1px;height:1px}.paper-grid{background:#fff;border-radius:14px;padding:0 26px}.paper-card{padding:24px 0;border-bottom:1px solid #c5d1e3;min-width:0}.paper-card:last-child{border-bottom:0}.paper-card h2{font-size:21px;line-height:1.5;font-weight:600;max-width:66ch;margin:0 0 12px}a{color:#18304d;text-decoration-thickness:1px;text-underline-offset:5px;overflow-wrap:anywhere}a:hover{color:#254dcc}.badge{display:inline-block;font-size:14px;color:#485c77;background:#f5f8ff;border-radius:4px;padding:2px 8px;margin:0 8px 4px 0}.count{display:none;color:#485c77;margin:0 0 12px}a:focus-visible{outline:3px solid #254dcc;outline-offset:4px}.empty{padding:26px 0;max-width:65ch}@media(max-width:700px){main{padding:16px}header{padding:26px 22px;margin-bottom:22px}.reading-desk{padding-left:0}.filters{position:static;width:auto;flex-direction:row;flex-wrap:wrap;margin-bottom:18px}.paper-grid{padding:0 18px}.paper-card{padding:22px 0}.paper-card h2{font-size:19px}}@media print{body{background:white}header{background:white;color:#18304d;padding:0}.filters,.domain-radio{display:none}.reading-desk{padding-left:0}.paper-grid .paper-card{display:block!important;break-inside:avoid}}
'''
    for cat in ['all']+groups:
        key = cat.replace('.', '-')
        css += '#filter-'+key+':checked~.filters label[for="filter-'+key+'"]{background:#254dcc;color:white;border-color:#254dcc}#filter-'+key+':focus-visible~.filters label[for="filter-'+key+'"]{outline:3px solid #18304d;outline-offset:3px}#filter-'+key+':checked~.count-'+key+'{display:block}'
        if cat != 'all':
            css += '#filter-'+key+':checked~.paper-grid .paper-card:not(.topic-'+key+'){display:none}'
    notice = 'Latest-paper coverage complete' if data['coverage_complete'] else 'Partial results: fewer than 30 papers or skipped/failed pages; coverage of the latest 30 papers is not guaranteed'
    parts = ['<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="design-skill" content="frontend-design"><meta http-equiv="Content-Security-Policy" content="default-src &#39;none&#39;; style-src &#39;unsafe-inline&#39;; base-uri &#39;none&#39;; form-action &#39;none&#39;"><title>Latest arXiv Papers</title><style>'+css+'</style></head><body><main>', '<header><h1>Latest arXiv Papers</h1><p>An index of titles, original links, and categories</p><p>Run time (Asia/Taipei): '+esc(data['invocation'])+'</p><p id="coverage">'+notice+'; collected '+str(len(papers))+' / 30 papers</p><p>Sorted by submittedDate, newest first, across ten fixed categories; this does not cover all AI papers. Category filters only change the display. This run does not mix historical caches.</p><ul>']
    for error in data['errors']:
        parts.append('<li>'+esc(json.dumps(error, ensure_ascii=False))+'</li>')
    parts.append('</ul></header><div class="reading-desk">')
    for cat in ['all']+groups:
        key = cat.replace('.', '-')
        parts.append('<input class="domain-radio" type="radio" name="domain" id="filter-'+key+'" aria-label="'+cat+'"'+(' checked' if cat=='all' else '')+'>')
    parts.append('<nav class="filters" aria-label="Category filters">')
    for cat in ['all']+groups:
        n = len(papers) if cat=='all' else sum(cat in p['categories'] for p in papers)
        parts.append('<label for="filter-'+cat.replace('.', '-')+'">'+('Show all / reset' if cat=='all' else cat)+' ('+str(n)+')</label>')
    parts.append('</nav>')
    for cat in ['all']+groups:
        n = len(papers) if cat=='all' else sum(cat in p['categories'] for p in papers)
        parts.append('<p class="count count-'+cat.replace('.', '-')+'">Matching '+str(n)+' / '+str(len(papers))+' papers</p>')
    parts.append('<section class="paper-grid" aria-label="Paper list">')
    for p in papers:
        cats = [c for c in CATEGORIES if c in p['categories']]
        parts.append('<article class="paper-card '+' '.join('topic-'+c.replace('.', '-') for c in cats)+'" data-paper-id="'+esc(p['id'], quote=True)+'"><h2><a class="paper-url" href="'+esc(p['url'], quote=True)+'" target="_blank" rel="noopener noreferrer">'+esc(p['title'])+'</a></h2>'+''.join('<span class="badge">'+c+'</span>' for c in cats)+'</article>')
    if not papers:
        parts.append('<p class="empty">No papers are available for this run; this is not a complete set of 30. Review the errors above, check source connectivity, and rerun the task.</p>')
    return '\n'.join(parts+['</section></div></main></body></html>'])
