# Device Monitor Agent Tools

Use this workspace to execute read-only device monitoring tasks. Select a Skill from the task type mapping, read its `SKILL.md`, and follow the documented command exactly.

## Skills

- [device-monitor](skills/device-monitor/SKILL.md)

## Task Type Mapping

| Task type | Skill | Purpose |
|---|---|---|
| `monitoring` | `device-monitor` | Repeated CPU, temperature, and disk monitoring with a Markdown report |
| `device_health_check` | `device-monitor` | Complete CPU, GPU, memory, disk, and thermal snapshot |
| `cpu_status` | `device-monitor` | CPU usage, load, core count, and temperature |
| `gpu_status` | `device-monitor` | GPU availability, utilization, memory, and temperature |
| `memory_status` | `device-monitor` | RAM and swap usage |
| `disk_status` | `device-monitor` | Disk capacity and usage for selected paths |
| `thermal_check` | `device-monitor` | Thermal-zone and GPU temperature inspection |

## Execution Rules

1. Read the selected Skill's `SKILL.md` before running a command.
2. Execute the Skill script directly from the Agent workspace in the current OpenClaw session.
3. Treat task-definition inputs as authoritative. Do not reduce iteration counts, change paths, or invent missing values.
4. Parse the script's JSON output and require `ok: true` before reporting success.
5. Report measured values exactly. Use `Unknown` when a sensor is unavailable; never estimate hardware data.
6. Do not modify system configuration, stop processes, install dependencies, or write outside the task's requested output path.
7. Return a concise result containing success or failure, the script summary, important warnings, and the output path when one exists.

Task lifecycle completion and dashboard notification are handled by the platform dispatch wrapper, not by this Agent or its Skills.
