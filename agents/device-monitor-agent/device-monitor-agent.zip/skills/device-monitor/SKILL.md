---
name: device-monitor
description: Read-only local hardware and resource monitoring for CPU, GPU, memory, disk, and thermal tasks. Use for a single snapshot or repeated CPU and disk monitoring with a Markdown report.
permissions:
  - env          # TASK_ID only
  - file_read    # /proc, /sys, and the report it wrote earlier
  - file_write   # the requested report path only
  - shell        # nvidia-smi / rocm-smi, fixed argument lists
---

# Device Monitor

## Purpose

Collect local hardware metrics and assess device health. The scripts are read-only, use the Python standard library, and return structured JSON. They do not change system configuration.

## Execution

Run scripts directly from the Agent workspace with `python3`. Use task-definition values exactly and parse the JSON printed to standard output.

### Repeated CPU and Disk Monitoring

Use for task type `monitoring`:

```bash
python3 skills/device-monitor/scripts/monitoring_loop.py <iterations> <report_path> [--aspect all|cpu|temp|disk]
```

- Default `iterations`: `100`.
- `report_path` is required and is workspace-relative: the runtime working directory is this Agent's workspace root, so pass the Task's declared filename through unchanged. Do not resolve it under `TASK_ARTIFACT_DIR` — that directory is for intermediate and working files, and a declared Expected Output is never there.
- Default `--aspect`: `all`. Each sample records UTC time, CPU usage, CPU temperature, root-disk usage, and root-disk free space.
- A narrower aspect writes a narrower table: `cpu` → 時間 + CPU 使用率; `temp` → 時間 + CPU 溫度; `disk` → 時間 + Disk 使用率 + Disk 剩餘空間. Use it when a Task declares one report per measurement, otherwise the reports differ only by filename.
- An unknown aspect fails with `ASPECT_INVALID` rather than falling back to `all`.
- Missing temperature or disk data is rendered as `Unknown` without stopping later samples.
- Rounds of the same Task accumulate. The report carries `**Task:** <TASK_ID>`; a run whose
  platform-injected `TASK_ID` matches it appends its samples to the existing table. A different
  Task, a different `--aspect`, or no `TASK_ID` starts a fresh report — which is how a previous
  Task's leftover report gets cleared. `**總執行次數:**` and the time span always cover the whole
  table, so `verify_report.py` agrees with it.
- The report is removed before sampling starts, so a run that dies partway leaves no file and the
  platform reports the Expected Output as missing rather than accepting an older one.
- Success JSON includes `ok`, `summary`, `iterations_completed`, `rows_carried`, `rows_total`,
  `started_at`, `finished_at`, `report_path`, and `warnings`.
- Environment: `TASK_ID` (platform-injected) is what makes rounds accumulate; nothing else is read.

### Per-Round Measurement Log

Use as the logging step of a repeated monitoring Task:

```bash
python3 skills/device-monitor/scripts/log_round.py <report_path> [task_id]
```

- Reads the newest sample row out of the report and prints it. The platform captures Skill
  output into the Task log, so printing is what records it; this script writes no log file.
- The line is built from the report's own table header, so any `--aspect` works and the column
  names in the line are the ones in the report.
- The caller never retypes the measurements — a Task step that asks for them inline gets the
  instruction's placeholder text recorded instead of the numbers.
- Environment: `TASK_ID` (platform-injected) is the default task id. Nothing else is read.

### Monitoring Report Check

Use after `monitoring_loop.py` when the Task requires the round to be verified:

```bash
python3 skills/device-monitor/scripts/verify_report.py <report_path>
```

- Exit code `0` means the round counts; `1` means it does not.
- Checks that the report exists, is not empty, has the sampling table, has at least one sample
  row with no blank cell, and that the row count matches the declared `總執行次數`.
- The column count comes from the report's own header, so any `--aspect` verifies the same way.
- Takes one report file. Passing a directory fails with `報告讀取失敗` — verify each report.
- `Unknown` is an accepted cell value; a blank cell is not.

### Full Device Snapshot

Use for task type `device_health_check`:

```bash
python3 skills/device-monitor/scripts/device_health_probe.py [disk_path ...]
```

The default disk path is `/`. Output contains `cpu`, `gpu`, `memory`, `disk`, `thermal`, `health`, and `warnings`.

### CPU Status

Use for task type `cpu_status`:

```bash
python3 skills/device-monitor/scripts/cpu_probe.py
```

Output contains CPU usage percentage, core count, load averages, and temperature.

### GPU Status

Use for task type `gpu_status`:

```bash
python3 skills/device-monitor/scripts/gpu_probe.py
```

Output contains GPU availability, vendor, name, utilization, memory usage, and temperature. Missing NVIDIA/AMD utilities produce `available: false` rather than fabricated values.

### Memory Status

Use for task type `memory_status`:

```bash
python3 skills/device-monitor/scripts/memory_probe.py
```

Output contains total, used, and available RAM plus swap metrics.

### Disk Status

Use for task type `disk_status`:

```bash
python3 skills/device-monitor/scripts/disk_probe.py [path ...]
```

The default path is `/`. Output contains total, used, and free bytes plus usage percentage for every requested path.

### Thermal Check

Use for task type `thermal_check`:

```bash
python3 skills/device-monitor/scripts/thermal_probe.py
```

Output contains detected thermal zones, GPU temperature when available, maximum temperature, and overheat state.

## Health Thresholds

| Metric | Warning | Critical |
|---|---:|---:|
| CPU usage snapshot | `>= 85%` | `>= 95%` |
| CPU usage in repeated monitoring | `>= 80%` | `>= 95%` |
| Memory usage | `>= 80%` | `>= 90%` |
| Disk usage | `>= 85%` | `>= 95%` |
| CPU temperature | `>= 75°C` | `>= 90°C` |
| GPU temperature | `>= 80°C` | `>= 95°C` |

## Result Handling

1. Require a successful process exit and valid JSON.
2. Check `ok`, `summary`, `health`, `warnings`, and `errors` when present.
3. For repeated monitoring, additionally verify `iterations_completed`, `report_path`, and that the report exists and is not empty.
4. Return actual measurements and warnings without rewriting values.
5. If `ok` is false or execution fails, return the actual error and do not claim completion.

The platform dispatch wrapper owns task finalization and dashboard notification. This Skill only executes the requested monitoring operation and returns its result.

## Constraints

- Local-machine inspection only.
- Read-only system probes; the repeated monitor writes only its requested report.
- Python standard library only; no package installation is required.
- A single snapshot probe should finish within 30 seconds.
- Sensor or GPU utility absence must be reported as unavailable or `Unknown`.
