#!/usr/bin/env python3
"""Probe CPU usage, load averages, and temperature.

Returns JSON with ok, summary, health, and cpu fields.
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any


def read_proc_stat() -> tuple[int, int]:
    with open("/proc/stat", encoding="utf-8") as fh:
        fields = fh.readline().split()[1:]
    values = [int(v) for v in fields]
    idle = values[3] + (values[4] if len(values) > 4 else 0)
    return idle, sum(values)


def cpu_percent() -> float | None:
    try:
        idle1, total1 = read_proc_stat()
        time.sleep(0.2)
        idle2, total2 = read_proc_stat()
        delta = total2 - total1
        return round((1 - (idle2 - idle1) / delta) * 100, 1) if delta > 0 else None
    except Exception:
        return None


def cpu_temperature() -> float | None:
    """Read from /sys/class/thermal/thermal_zone*/temp (millidegrees)."""
    temps: list[float] = []
    for zone in sorted(Path("/sys/class/thermal").glob("thermal_zone*")):
        try:
            temp_file = zone / "temp"
            type_file = zone / "type"
            if not temp_file.exists():
                continue
            zone_type = type_file.read_text(encoding="utf-8").strip() if type_file.exists() else ""
            # Skip GPU / fan zones — prefer CPU / x86_pkg zones
            if any(k in zone_type.lower() for k in ("gpu", "fan", "pch", "wifi")):
                continue
            value = float(temp_file.read_text(encoding="utf-8").strip()) / 1000.0
            temps.append(value)
        except Exception:
            continue
    return max(temps) if temps else None


def health(percent: float | None, temp: float | None) -> str:
    if percent is None:
        return "unknown"
    if percent >= 95 or (temp is not None and temp >= 90):
        return "critical"
    if percent >= 85 or (temp is not None and temp >= 75):
        return "warning"
    return "healthy"


def main() -> None:
    loads = os.getloadavg() if hasattr(os, "getloadavg") else (None, None, None)
    percent = cpu_percent()
    temp = cpu_temperature()
    status = health(percent, temp)

    warnings: list[str] = []
    if percent is not None and percent >= 85:
        warnings.append(f"CPU usage {percent}% exceeds warning threshold.")
    if temp is not None and temp >= 75:
        warnings.append(f"CPU temperature {temp} °C exceeds warning threshold.")

    summary = f"CPU {percent}%" if percent is not None else "CPU usage unavailable"
    if temp is not None:
        summary += f", {temp} °C"
    summary += f" — {status}."

    print(json.dumps({
        "ok": status != "unknown",
        "summary": summary,
        "health": status,
        "cpu": {
            "percent": percent,
            "count": os.cpu_count(),
            "load_1m": loads[0],
            "load_5m": loads[1],
            "load_15m": loads[2],
            "temperature_c": temp,
        },
        "warnings": warnings,
        "errors": [],
    }, indent=2))


if __name__ == "__main__":
    main()
