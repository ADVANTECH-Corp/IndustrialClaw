#!/usr/bin/env python3
"""Comprehensive device health probe: CPU + GPU + RAM + Disk + Thermal in one call.

Usage: device_health_probe.py [disk_path1 disk_path2 ...]
If no disk paths are given, defaults to /.

Returns JSON with ok, summary, health, and per-subsystem data.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any


# ── CPU ───────────────────────────────────────────────────────────────────────

def _read_proc_stat() -> tuple[int, int]:
    with open("/proc/stat", encoding="utf-8") as fh:
        f = fh.readline().split()[1:]
    v = [int(x) for x in f]
    idle = v[3] + (v[4] if len(v) > 4 else 0)
    return idle, sum(v)


def _cpu_percent() -> float | None:
    try:
        i1, t1 = _read_proc_stat()
        time.sleep(0.2)
        i2, t2 = _read_proc_stat()
        d = t2 - t1
        return round((1 - (i2 - i1) / d) * 100, 1) if d > 0 else None
    except Exception:
        return None


def _cpu_temp() -> float | None:
    temps: list[float] = []
    for zone in sorted(Path("/sys/class/thermal").glob("thermal_zone*")):
        try:
            tf = zone / "temp"
            zt = (zone / "type").read_text(encoding="utf-8").strip() if (zone / "type").exists() else ""
            if any(k in zt.lower() for k in ("gpu", "fan", "pch", "wifi")):
                continue
            if tf.exists():
                temps.append(float(tf.read_text(encoding="utf-8").strip()) / 1000.0)
        except Exception:
            continue
    return max(temps) if temps else None


def collect_cpu() -> dict[str, Any]:
    loads = os.getloadavg() if hasattr(os, "getloadavg") else (None, None, None)
    return {
        "percent": _cpu_percent(),
        "count": os.cpu_count(),
        "load_1m": loads[0],
        "load_5m": loads[1],
        "load_15m": loads[2],
        "temperature_c": _cpu_temp(),
    }


# ── GPU ───────────────────────────────────────────────────────────────────────

def _safe_float(v: str) -> float | None:
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _run(args: list[str]) -> str | None:
    try:
        r = subprocess.run(args, check=False, text=True, capture_output=True, timeout=5)
        return r.stdout.strip() if r.returncode == 0 else None
    except Exception:
        return None


def collect_gpu() -> dict[str, Any]:
    out = _run(["nvidia-smi",
                "--query-gpu=name,utilization.gpu,memory.total,memory.used,temperature.gpu",
                "--format=csv,noheader,nounits"])
    if out:
        parts = [p.strip() for p in out.splitlines()[0].split(",")]
        if len(parts) >= 5:
            total_mb = _safe_float(parts[2])
            used_mb = _safe_float(parts[3])
            total = int(total_mb) * 1024 * 1024 if total_mb is not None else None
            used = int(used_mb) * 1024 * 1024 if used_mb is not None else None
            return {
                "available": True, "vendor": "nvidia", "name": parts[0],
                "util_percent": _safe_float(parts[1]),
                "memory_total_bytes": total, "memory_used_bytes": used,
                "memory_percent": round(used / total * 100, 1) if total and used else None,
                "temperature_c": _safe_float(parts[4]),
            }
    return {
        "available": False, "vendor": None, "name": None,
        "util_percent": None, "memory_total_bytes": None,
        "memory_used_bytes": None, "memory_percent": None, "temperature_c": None,
    }


# ── Memory ────────────────────────────────────────────────────────────────────

def collect_memory() -> dict[str, Any] | None:
    data: dict[str, int] = {}
    try:
        with open("/proc/meminfo", encoding="utf-8") as fh:
            for line in fh:
                k, raw = line.split(":", 1)
                parts = raw.strip().split()
                if parts and parts[0].isdigit():
                    data[k.strip()] = int(parts[0]) * 1024
    except Exception:
        return None
    total = data.get("MemTotal")
    avail = data.get("MemAvailable") or data.get("MemFree")
    used = total - avail if total and avail is not None else None
    swap_total = data.get("SwapTotal")
    swap_free = data.get("SwapFree")
    swap_used = swap_total - swap_free if swap_total is not None and swap_free is not None else None
    return {
        "total_bytes": total, "used_bytes": used, "available_bytes": avail,
        "percent": round(used / total * 100, 1) if total and used is not None else None,
        "swap_total_bytes": swap_total, "swap_used_bytes": swap_used,
        "swap_percent": round(swap_used / swap_total * 100, 1) if swap_total and swap_used is not None else None,
    }


# ── Disk ──────────────────────────────────────────────────────────────────────

def collect_disk(paths: list[Path]) -> list[dict[str, Any]]:
    records = []
    for path in paths:
        rec: dict[str, Any] = {"path": str(path), "exists": path.exists()}
        if path.exists():
            try:
                u = shutil.disk_usage(path)
                rec.update({
                    "total_bytes": u.total, "used_bytes": u.used, "free_bytes": u.free,
                    "percent": round(u.used / u.total * 100, 1) if u.total else None,
                })
            except Exception as exc:
                rec.update({"total_bytes": None, "used_bytes": None, "free_bytes": None,
                             "percent": None, "error": str(exc)})
        else:
            rec.update({"total_bytes": None, "used_bytes": None, "free_bytes": None,
                         "percent": None})
        records.append(rec)
    return records


# ── Thermal ───────────────────────────────────────────────────────────────────

def collect_thermal() -> dict[str, Any]:
    zones: list[dict[str, Any]] = []
    for zone in sorted(Path("/sys/class/thermal").glob("thermal_zone*")):
        try:
            tf = zone / "temp"
            zt = (zone / "type").read_text(encoding="utf-8").strip() if (zone / "type").exists() else "unknown"
            if tf.exists():
                temp_c = float(tf.read_text(encoding="utf-8").strip()) / 1000.0
                zones.append({"zone": zone.name, "type": zt, "temperature_c": temp_c})
        except Exception:
            continue
    gpu_temp: float | None = None
    out = _run(["nvidia-smi", "--query-gpu=temperature.gpu", "--format=csv,noheader,nounits"])
    if out:
        first = out.splitlines()[0].strip()
        if first and first != "[N/A]":
            gpu_temp = _safe_float(first)
    all_temps = [z["temperature_c"] for z in zones]
    if gpu_temp is not None:
        all_temps.append(gpu_temp)
    return {
        "zones": zones,
        "gpu_temperature_c": gpu_temp,
        "max_temperature_c": max(all_temps) if all_temps else None,
    }


# ── Aggregate health ──────────────────────────────────────────────────────────

def aggregate_health(cpu: dict, mem: dict | None, disk_records: list, thermal: dict) -> tuple[str, list[str]]:
    warnings: list[str] = []
    levels: list[str] = []

    cpu_p = cpu.get("percent")
    if cpu_p is not None:
        if cpu_p >= 95:
            levels.append("critical")
            warnings.append(f"CPU usage {cpu_p}% — CRITICAL.")
        elif cpu_p >= 85:
            levels.append("warning")
            warnings.append(f"CPU usage {cpu_p}% — warning.")

    cpu_t = cpu.get("temperature_c")
    if cpu_t is not None:
        if cpu_t >= 90:
            levels.append("critical")
            warnings.append(f"CPU temperature {cpu_t} °C — CRITICAL.")
        elif cpu_t >= 75:
            levels.append("warning")
            warnings.append(f"CPU temperature {cpu_t} °C — warning.")

    if mem:
        mem_p = mem.get("percent")
        if mem_p is not None:
            if mem_p >= 90:
                levels.append("critical")
                warnings.append(f"RAM usage {mem_p}% — CRITICAL.")
            elif mem_p >= 80:
                levels.append("warning")
                warnings.append(f"RAM usage {mem_p}% — warning.")

    for r in disk_records:
        dp = r.get("percent")
        if dp is not None:
            if dp >= 95:
                levels.append("critical")
                warnings.append(f"Disk {r['path']} {dp}% — CRITICAL.")
            elif dp >= 85:
                levels.append("warning")
                warnings.append(f"Disk {r['path']} {dp}% — warning.")

    max_temp = thermal.get("max_temperature_c")
    if max_temp is not None:
        if max_temp >= 90:
            levels.append("critical")
            warnings.append(f"Temperature {max_temp} °C — CRITICAL overheat.")
        elif max_temp >= 75:
            levels.append("warning")
            warnings.append(f"Temperature {max_temp} °C — thermal warning.")

    if "critical" in levels:
        return "critical", warnings
    if "warning" in levels:
        return "warning", warnings
    if cpu_p is None and mem is None:
        return "unknown", warnings
    return "healthy", warnings


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    disk_paths = [Path(p) for p in sys.argv[1:]] or [Path("/")]

    cpu = collect_cpu()
    gpu = collect_gpu()
    mem = collect_memory()
    disk_records = collect_disk(disk_paths)
    thermal = collect_thermal()

    status, warnings = aggregate_health(cpu, mem, disk_records, thermal)

    # Build concise summary
    parts: list[str] = []
    if cpu.get("percent") is not None:
        parts.append(f"CPU {cpu['percent']}%")
    if gpu.get("available") and gpu.get("util_percent") is not None:
        parts.append(f"GPU {gpu['util_percent']}%")
    if mem and mem.get("percent") is not None:
        parts.append(f"RAM {mem['percent']}%")
    worst_disk = max((r for r in disk_records if r.get("percent") is not None),
                     key=lambda r: r["percent"], default=None)
    if worst_disk:
        parts.append(f"Disk {worst_disk['percent']}%")
    if thermal.get("max_temperature_c") is not None:
        parts.append(f"{thermal['max_temperature_c']} °C")

    summary = (", ".join(parts) + f" — {status}.") if parts else f"Device health {status}."

    print(json.dumps({
        "ok": status not in ("critical", "unknown"),
        "summary": summary,
        "health": status,
        "cpu": cpu,
        "gpu": gpu,
        "memory": mem or {},
        "disk": {"paths": disk_records},
        "thermal": thermal,
        "warnings": warnings,
        "errors": [],
    }, indent=2))


if __name__ == "__main__":
    main()
