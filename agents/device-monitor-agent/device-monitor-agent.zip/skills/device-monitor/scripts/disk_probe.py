#!/usr/bin/env python3
"""Probe disk usage for one or more filesystem paths.

Usage: disk_probe.py [path1 path2 ...]
If no paths are given, defaults to /.

Returns JSON with ok, summary, health, and disk fields.
"""
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path
from typing import Any


def check_path(path: Path) -> dict[str, Any]:
    record: dict[str, Any] = {"path": str(path), "exists": path.exists()}
    if not path.exists():
        record.update({"total_bytes": None, "used_bytes": None, "free_bytes": None, "percent": None,
                        "error": "Path does not exist."})
        return record
    try:
        usage = shutil.disk_usage(path)
        record.update({
            "total_bytes": usage.total,
            "used_bytes": usage.used,
            "free_bytes": usage.free,
            "percent": round(usage.used / usage.total * 100, 1) if usage.total else None,
        })
    except Exception as exc:
        record.update({"total_bytes": None, "used_bytes": None, "free_bytes": None,
                        "percent": None, "error": str(exc)})
    return record


def health(records: list[dict[str, Any]]) -> str:
    percents = [r["percent"] for r in records if r.get("percent") is not None]
    if not percents:
        return "unknown"
    if max(percents) >= 95:
        return "critical"
    if max(percents) >= 85:
        return "warning"
    return "healthy"


def main() -> None:
    paths = [Path(p) for p in sys.argv[1:]] or [Path("/")]
    records = [check_path(p) for p in paths]
    status = health(records)

    warnings: list[str] = []
    errors: list[dict[str, Any]] = []
    for r in records:
        if r.get("percent") is not None and r["percent"] >= 85:
            warnings.append(f"Disk {r['path']} at {r['percent']}% exceeds warning threshold.")
        if r.get("error"):
            errors.append({"code": "DISK_READ_FAILED", "path": r["path"], "reason": r["error"]})

    worst = max((r for r in records if r.get("percent") is not None),
                key=lambda r: r["percent"], default=None)
    if worst:
        summary = f"Disk {worst['path']} {worst['percent']}% used — {status}."
    else:
        summary = f"Disk usage unavailable for {[str(p) for p in paths]}."

    print(json.dumps({
        "ok": bool(records) and not errors,
        "summary": summary,
        "health": status,
        "disk": {"paths": records},
        "warnings": warnings,
        "errors": errors,
    }, indent=2))


if __name__ == "__main__":
    main()
