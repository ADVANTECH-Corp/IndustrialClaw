#!/usr/bin/env python3
"""Probe GPU utilisation, VRAM usage, and temperature (NVIDIA or AMD).

Returns JSON with ok, summary, health, and gpu fields.
"""
from __future__ import annotations

import json
import subprocess
from typing import Any


def _run(args: list[str]) -> str | None:
    try:
        result = subprocess.run(args, check=False, text=True, capture_output=True, timeout=5)
        return result.stdout.strip() if result.returncode == 0 else None
    except Exception:
        return None


def _safe_float(value: str) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def collect_nvidia() -> dict[str, Any] | None:
    query = "name,utilization.gpu,memory.total,memory.used,temperature.gpu"
    out = _run(["nvidia-smi", f"--query-gpu={query}", "--format=csv,noheader,nounits"])
    if not out:
        return None
    parts = [p.strip() for p in out.splitlines()[0].split(",")]
    if len(parts) < 5:
        return None
    total_mb = _safe_float(parts[2])
    used_mb = _safe_float(parts[3])
    total = int(total_mb) * 1024 * 1024 if total_mb is not None else None
    used = int(used_mb) * 1024 * 1024 if used_mb is not None else None
    return {
        "available": True,
        "vendor": "nvidia",
        "name": parts[0],
        "util_percent": _safe_float(parts[1]),
        "memory_total_bytes": total,
        "memory_used_bytes": used,
        "memory_percent": round(used / total * 100, 1) if total and used else None,
        "temperature_c": _safe_float(parts[4]),
    }


def collect_amd() -> dict[str, Any] | None:
    out = _run(["rocm-smi", "--showuse", "--showmemuse", "--showtemp", "--json"])
    if not out:
        return None
    try:
        data = json.loads(out)
        card = next(iter(data.values())) if isinstance(data, dict) and data else {}
        util = card.get("GPU use (%)") or card.get("GPU Use (%)")
        mem = card.get("GPU Memory Allocated (VRAM%)") or card.get("GPU memory use (%)")
        temp = card.get("Temperature (Sensor edge) (C)") or card.get("Temperature (Sensor junction) (C)")
        return {
            "available": True,
            "vendor": "amd",
            "name": card.get("Card series") or card.get("GPU ID"),
            "util_percent": float(util) if util is not None else None,
            "memory_total_bytes": None,
            "memory_used_bytes": None,
            "memory_percent": float(mem) if mem is not None else None,
            "temperature_c": float(temp) if temp is not None else None,
        }
    except Exception:
        return None


def health(gpu: dict[str, Any]) -> str:
    if not gpu.get("available"):
        return "unknown"
    temp = gpu.get("temperature_c")
    util = gpu.get("util_percent")
    mem = gpu.get("memory_percent")
    if (temp is not None and temp >= 95) or (util is not None and util >= 98) or (mem is not None and mem >= 98):
        return "critical"
    if (temp is not None and temp >= 80) or (util is not None and util >= 90) or (mem is not None and mem >= 90):
        return "warning"
    return "healthy"


def main() -> None:
    gpu = collect_nvidia() or collect_amd() or {
        "available": False, "vendor": None, "name": None,
        "util_percent": None, "memory_total_bytes": None,
        "memory_used_bytes": None, "memory_percent": None, "temperature_c": None,
    }
    status = health(gpu)

    warnings: list[str] = []
    if gpu.get("available"):
        temp = gpu.get("temperature_c")
        util = gpu.get("util_percent")
        if temp is not None and temp >= 80:
            warnings.append(f"GPU temperature {temp} °C exceeds warning threshold.")
        if util is not None and util >= 90:
            warnings.append(f"GPU utilisation {util}% exceeds warning threshold.")

    if gpu.get("available"):
        summary = f"GPU {gpu.get('name', 'unknown')}: util {gpu.get('util_percent')}%"
        if gpu.get("memory_percent") is not None:
            summary += f", VRAM {gpu.get('memory_percent')}%"
        if gpu.get("temperature_c") is not None:
            summary += f", {gpu.get('temperature_c')} °C"
        summary += f" — {status}."
    else:
        summary = "GPU unavailable (nvidia-smi and rocm-smi not found)."

    print(json.dumps({
        "ok": gpu.get("available", False),
        "summary": summary,
        "health": status,
        "gpu": gpu,
        "warnings": warnings,
        "errors": [] if gpu.get("available") else [{"code": "GPU_UNAVAILABLE", "reason": "No GPU tool found."}],
    }, indent=2))


if __name__ == "__main__":
    main()
