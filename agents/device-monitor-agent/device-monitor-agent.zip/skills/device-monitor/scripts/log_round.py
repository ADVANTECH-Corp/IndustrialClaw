#!/usr/bin/env python3
"""Report this round's ACTUAL measurements so they land in the Task log.

The values are read back out of the report that was just written, never retyped by the caller.
A model asked to put its measurements into a command writes `cpu=<CPU_VALUE>` — the placeholder
from the instruction — because it does not carry the numbers between tool calls. So the numbers
come from the file, and the caller only has to run one fixed command.

Everything a Skill prints is captured into the Task log by the platform, so emitting the line is
all this has to do -- it never reaches into a platform path to write the log itself.

The report's own table header names the columns, so a report written with any --aspect logs
its own measurements; nothing here assumes a fixed column set.

Usage: log_round.py <report_path> [task_id]
  task_id defaults to $TASK_ID, which the platform injects into every Skill execution.

Environment:
  TASK_ID   Platform-injected. Used when task_id is not given as an argument.
"""
from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path

DATA_ROW = re.compile(r"^\|\s*\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}\s*\|")
# The report's own header names the columns. monitoring_loop.py writes a different set per
# --aspect, so the log line is built from the header rather than from a fixed column list.
HEADER_PREFIX = "| 時間 |"


def emit(ok: bool, summary: str, **extra: object) -> int:
    print(json.dumps({"ok": ok, "summary": summary, "small_model_summary": summary[:80],
                      "warnings": [], "errors": [] if ok else [{"message": summary}], **extra},
                     ensure_ascii=False, indent=2))
    return 0 if ok else 1


def main() -> int:
    if len(sys.argv) < 2 or not sys.argv[1].strip():
        return emit(False, "缺少報告路徑 (Usage: log_round.py <report_path> [task_id])")
    task_id = (sys.argv[2] if len(sys.argv) > 2 else "").strip() or os.environ.get("TASK_ID", "")
    if not task_id:
        return emit(False, "缺少 task_id：未給參數，環境也沒有 TASK_ID")

    path = Path(sys.argv[1])
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        return emit(False, f"報告讀取失敗: {exc}", report_path=str(path))
    header = next((line for line in lines if line.strip().startswith(HEADER_PREFIX)), None)
    if header is None:
        return emit(False, "報告缺少監控表格標頭", report_path=str(path))
    columns = [cell.strip() for cell in header.strip().strip("|").split("|")]
    rows = [line for line in lines if DATA_ROW.match(line.strip())]
    if not rows:
        return emit(False, "報告沒有任何一列採樣資料，沒有東西可以記錄", report_path=str(path))

    cells = [cell.strip() for cell in rows[-1].strip().strip("|").split("|")]
    if len(cells) != len(columns):
        return emit(False, f"採樣列欄數與標頭不符（標頭 {len(columns)}，資料 {len(cells)}）: "
                           f"{rows[-1].strip()}", report_path=str(path))
    ts = cells[0]
    line = f"[{ts}] " + " | ".join(f"{name}={value}"
                                  for name, value in zip(columns[1:], cells[1:]))

    return emit(True, f"已記錄這一輪的實際數值: {line}", task_id=task_id, logged=line,
                report_path=str(path))


if __name__ == "__main__":
    raise SystemExit(main())
