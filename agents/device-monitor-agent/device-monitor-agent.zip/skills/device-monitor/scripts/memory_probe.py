#!/usr/bin/env python3
"""Probe RAM and swap usage from /proc/meminfo.

Returns JSON with ok, summary, health, and memory fields.
"""
from __future__ import annotations

import json
from typing import Any


def parse_meminfo() -> dict[str, int] | None:
    data: dict[str, int] = {}
    try:
        with open("/proc/meminfo", encoding="utf-8") as fh:
            for line in fh:
                key, raw = line.split(":", 1)
                parts = raw.strip().split()
                if parts and parts[0].isdigit():
                    data[key.strip()] = int(parts[0]) * 1024
    except Exception:
        return None
    return data


def health(mem_percent: float | None, swap_percent: float | None) -> str:
    if mem_percent is None:
        return "unknown"
    if mem_percent >= 90 or (swap_percent is not None and swap_percent >= 90):
        return "critical"
    if mem_percent >= 80 or (swap_percent is not None and swap_percent >= 80):
        return "warning"
    return "healthy"


def main() -> None:
    mem = parse_meminfo()
    warnings: list[str] = []

    if mem is None:
        print(json.dumps({
            "ok": False,
            "summary": "Could not read /proc/meminfo.",
            "health": "unknown",
            "memory": {},
            "warnings": [],
            "errors": [{"code": "MEMINFO_UNAVAILABLE", "reason": "/proc/meminfo could not be read."}],
        }, indent=2))
        return

    total = mem.get("MemTotal")
    available = mem.get("MemAvailable") or mem.get("MemFree")
    used = total - available if total and available is not None else None
    mem_percent = round(used / total * 100, 1) if total and used is not None else None

    swap_total = mem.get("SwapTotal")
    swap_free = mem.get("SwapFree")
    swap_used = swap_total - swap_free if swap_total is not None and swap_free is not None else None
    swap_percent = round(swap_used / swap_total * 100, 1) if swap_total and swap_used is not None else None

    status = health(mem_percent, swap_percent)

    if mem_percent is not None and mem_percent >= 80:
        warnings.append(f"RAM usage {mem_percent}% exceeds warning threshold.")
    if swap_percent is not None and swap_percent >= 80:
        warnings.append(f"Swap usage {swap_percent}% exceeds warning threshold.")

    def _mb(b: int | None) -> float | None:
        return round(b / 1024 / 1024, 1) if b is not None else None

    summary = (
        f"RAM {mem_percent}% used ({_mb(used)} MB / {_mb(total)} MB)"
        if mem_percent is not None else "RAM usage unavailable"
    )
    summary += f" — {status}."

    print(json.dumps({
        "ok": status != "unknown",
        "summary": summary,
        "health": status,
        "memory": {
            "total_bytes": total,
            "used_bytes": used,
            "available_bytes": available,
            "percent": mem_percent,
            "swap_total_bytes": swap_total,
            "swap_used_bytes": swap_used,
            "swap_percent": swap_percent,
        },
        "warnings": warnings,
        "errors": [],
    }, indent=2))


if __name__ == "__main__":
    main()
