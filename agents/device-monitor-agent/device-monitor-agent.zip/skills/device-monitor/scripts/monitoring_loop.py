#!/usr/bin/env python3
"""Iterative monitoring loop: CPU usage/temp + Disk usage/free for N iterations.

Usage: monitoring_loop.py [iterations] <report_path> [--aspect all|cpu|temp|disk]
  iterations  Number of monitoring cycles (default: 100)
  report_path    Markdown report path, relative to the Agent workspace
  --aspect  Which columns the report carries (default: all). A Task that writes one
            report per measurement wants one aspect each, otherwise the three reports
            differ only by filename.

Each iteration takes ~0.5 s (CPU delta sample). Total runtime ≈ iterations × 0.5 s.
Returns JSON with ok, summary, and report_path.

The rounds of one Task accumulate into one report: the report carries the Task id, and a run
whose $TASK_ID matches it appends to the table instead of starting over. Anything else -- a
different Task, a different --aspect, no $TASK_ID -- writes a fresh report, which is also how a
previous Task's leftover report is cleared.

Environment:
  TASK_ID   Platform-injected. Absent (running by hand) means every run starts a fresh report.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


# The rounds of one Task accumulate into one report. The platform re-runs every declared Step
# each round and gives the Skill no round number, so the Task id stamped in the header is the
# only thing that separates "another round of this Task" from "a report an earlier Task left in
# the workspace". TASK_ID is injected into every Skill execution by the platform.
TASK_LINE = "**Task:** "
DATA_ROW = re.compile(r"^\|\s*\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}\s*\|")


def carry_over(path: Path, task_id: str, columns: list[str]) -> tuple[list[str], list[str]]:
    """This Task's earlier rounds, read back out of the report it already wrote.

    Empty whenever the file cannot be shown to belong to this Task and this column set: no Task
    id (running by hand), a different one (an earlier Task's leftover report), a different
    `--aspect`, or a file that will not read. The caller then starts a fresh report, which is
    also how a previous Task's report gets cleared.
    """
    if not task_id:
        return [], []
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return [], []
    stamp = next((line[len(TASK_LINE):].strip()
                  for line in lines if line.startswith(TASK_LINE)), "")
    if stamp != task_id:
        return [], []
    header = next((line for line in lines if line.strip().startswith("| 時間 |")), "")
    if [cell.strip() for cell in header.strip().strip("|").split("|")] != columns:
        return [], []
    return ([line for line in lines if DATA_ROW.match(line.strip())],
            [line[2:] for line in lines if line.startswith("- ")])


def row_time(row: str) -> str:
    """The timestamp cell of a data row."""
    return row.strip().strip("|").split("|")[0].strip()


# ---------------------------------------------------------------------------
# System readers (stdlib only)
# ---------------------------------------------------------------------------

def _read_proc_stat() -> tuple[int, int]:
    with open("/proc/stat", encoding="utf-8") as fh:
        fields = fh.readline().split()[1:]
    values = [int(v) for v in fields]
    idle = values[3] + (values[4] if len(values) > 4 else 0)
    return idle, sum(values)


def cpu_percent(sample_sec: float = 0.4) -> float | None:
    try:
        idle1, total1 = _read_proc_stat()
        time.sleep(sample_sec)
        idle2, total2 = _read_proc_stat()
        delta = total2 - total1
        return round((1 - (idle2 - idle1) / delta) * 100, 1) if delta > 0 else None
    except Exception:
        return None


def cpu_temperature() -> float | None:
    temps: list[float] = []
    try:
        for zone in sorted(Path("/sys/class/thermal").glob("thermal_zone*")):
            temp_file = zone / "temp"
            type_file = zone / "type"
            if not temp_file.exists():
                continue
            zone_type = type_file.read_text(encoding="utf-8").strip() if type_file.exists() else ""
            if any(k in zone_type.lower() for k in ("gpu", "fan", "pch", "wifi")):
                continue
            temps.append(float(temp_file.read_text(encoding="utf-8").strip()) / 1000.0)
    except Exception:
        pass
    return max(temps) if temps else None


def disk_info(path: str = "/") -> tuple[float | None, float | None]:
    try:
        usage = shutil.disk_usage(path)
        pct = round(usage.used / usage.total * 100, 1) if usage.total else None
        free_gb = round(usage.free / (1024 ** 3), 2)
        return pct, free_gb
    except Exception:
        return None, None


# ---------------------------------------------------------------------------
# Health labels
# ---------------------------------------------------------------------------

def cpu_label(pct: float | None, temp: float | None) -> str:
    if pct is None:
        return "Unknown"
    if pct >= 95 or (temp is not None and temp >= 90):
        return f"{pct}% 🔴 Critical"
    if pct >= 80 or (temp is not None and temp >= 75):
        return f"{pct}% ⚠️ Warning"
    return f"{pct}% ✅"


def temp_label(temp: float | None) -> str:
    if temp is None:
        return "Unknown"
    if temp >= 90:
        return f"{temp}°C 🔴 Critical"
    if temp >= 75:
        return f"{temp}°C ⚠️ Warning"
    return f"{temp}°C ✅"


def disk_label(pct: float | None) -> str:
    if pct is None:
        return "Unknown"
    if pct >= 95:
        return f"{pct}% 🔴 Critical"
    if pct >= 85:
        return f"{pct}% ⚠️ Warning"
    return f"{pct}% ✅"


def now_str() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


# The column set each aspect reports. Every aspect keeps the 時間 column in front, so a
# reader (and verify_report.py) can find the table the same way whatever was asked for.
ASPECTS: dict[str, tuple[str, ...]] = {
    "all": ("CPU 使用率", "CPU 溫度", "Disk 使用率", "Disk 剩餘空間"),
    "cpu": ("CPU 使用率",),
    "temp": ("CPU 溫度",),
    "disk": ("Disk 使用率", "Disk 剩餘空間"),
}


def measured_cells(pct: float | None, temp: float | None,
                   disk_pct: float | None, disk_free: float | None) -> dict[str, str]:
    """Every column this script knows how to fill. All four are always measured: the CPU
    sample costs ~0.4 s whatever the aspect, and cpu_label needs the temperature anyway."""
    return {
        "CPU 使用率": cpu_label(pct, temp),
        "CPU 溫度": temp_label(temp),
        "Disk 使用率": disk_label(disk_pct),
        "Disk 剩餘空間": f"{disk_free} GB" if disk_free is not None else "Unknown",
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    args = sys.argv[1:]
    iterations = 100

    aspect = "all"
    if "--aspect" in args:
        index = args.index("--aspect")
        aspect = args[index + 1] if index + 1 < len(args) else ""
        del args[index:index + 2]
    if aspect not in ASPECTS:
        print(json.dumps({
            "ok": False,
            "summary": f"未知的 --aspect: {aspect or '(空)'}",
            "errors": [{
                "error_code": "ASPECT_INVALID",
                "message": f"--aspect must be one of: {', '.join(ASPECTS)}",
            }],
        }, ensure_ascii=False, indent=2))
        return 2

    if args:
        try:
            iterations = max(1, int(args[0]))
        except (ValueError, TypeError):
            pass
    if len(args) < 2 or not args[1].strip():
        print(json.dumps({
            "ok": False,
            "summary": "缺少平台解析後的 Artifact 輸出路徑",
            "errors": [{
                "error_code": "ARTIFACT_PATH_REQUIRED",
                "message": "Usage: monitoring_loop.py [iterations] <report_path>",
            }],
        }, ensure_ascii=False, indent=2))
        return 2
    output_path = args[1]
    # TASK_ID is written into the report header that carry_over() reads back, so keep it to
    # one harmless token: a newline in it could forge a "**Task:**" line or table rows.
    task_id = re.sub(r"[^A-Za-z0-9._-]", "", os.environ.get("TASK_ID", ""))[:64]
    columns = ["時間", *ASPECTS[aspect]]

    # Carry this Task's earlier rounds in memory, then remove the file before sampling starts.
    # Clearing up front is what makes a run that dies halfway leave nothing behind: the platform
    # accepts an Expected Output on path existence alone, so a surviving report would be read as
    # this run's output.
    rows, warnings_log = carry_over(Path(output_path), task_id, columns)
    try:
        Path(output_path).unlink(missing_ok=True)
    except OSError as exc:
        print(json.dumps({
            "ok": False,
            "summary": f"無法清除既有報告: {exc}",
            "errors": [{"error_code": "REPORT_CLEAR_FAILED", "message": str(exc)}],
        }, ensure_ascii=False, indent=2))
        return 1
    carried = len(rows)

    started = now_str()

    for i in range(iterations):
        ts = now_str()
        pct = cpu_percent(sample_sec=0.4)   # ~0.4 s blocking sample
        temp = cpu_temperature()
        disk_pct, disk_free = disk_info("/")

        cells = measured_cells(pct, temp, disk_pct, disk_free)
        rows.append("| " + " | ".join([ts] + [cells[name] for name in ASPECTS[aspect]]) + " |")

        if pct is not None and pct >= 80:
            warnings_log.append(f"[{ts}] CPU {pct}%")
        if disk_pct is not None and disk_pct >= 85:
            warnings_log.append(f"[{ts}] Disk {disk_pct}%")

        # No extra sleep — the CPU delta sample already takes ~0.4 s.

    finished = now_str()

    # Build Markdown report. The counts and the time span cover every round carried in the
    # table, not just this one — verify_report.py cross-checks 總執行次數 against the row count.
    table_header = (
        "| " + " | ".join(columns) + " |\n"
        "| " + " | ".join([":---"] * len(columns)) + " |"
    )
    report_lines = [
        "# 設備狀態監控報告",
        "",
        f"{TASK_LINE}{task_id}" if task_id else f"{TASK_LINE}(none)",
        f"**監控時間範圍:** {row_time(rows[0]) if rows else started} ~ "
        f"{row_time(rows[-1]) if rows else finished}",
        f"**總執行次數:** {len(rows)}",
        "",
        table_header,
    ] + rows

    if warnings_log:
        report_lines += ["", "## ⚠️ 警告記錄", ""]
        report_lines += [f"- {w}" for w in warnings_log]
    else:
        report_lines += ["", "## ✅ 監控結果", "", "所有監控項目均在正常範圍內。"]

    report = "\n".join(report_lines) + "\n"

    out = Path(output_path)
    try:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(report, encoding="utf-8")
    except OSError as exc:
        print(json.dumps({
            "ok": False,
            "summary": f"監控完成，但報告儲存失敗: {exc}",
            "iterations_completed": iterations,
            "errors": [{"error_code": "REPORT_WRITE_FAILED", "message": str(exc)}],
        }, ensure_ascii=False, indent=2))
        return 1

    print(json.dumps({
        "ok": True,
        "summary": f"完成 {iterations} 次監控，報告已儲存至 {output_path}",
        "iterations_completed": iterations,
        "rows_carried": carried,
        "rows_total": len(rows),
        "started_at": started,
        "finished_at": finished,
        "report_path": str(out),
        "warnings": warnings_log,
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
