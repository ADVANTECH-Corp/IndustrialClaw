#!/usr/bin/env python3
"""Rounds of one Task accumulate into one report; anything else starts fresh."""

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parent.parent

# Only what the child interpreter needs to start, named one by one: the test is about TASK_ID,
# so the rest of this process's environment has no business reaching the subprocess.
PASSTHROUGH = ("PATH", "PYTHONPATH", "PYTHONHOME", "LD_LIBRARY_PATH", "TMPDIR")


def loop(path: Path, task_id: str | None, n: int = 2, aspect: str = "cpu") -> dict:
    env = {name: os.environ[name] for name in PASSTHROUGH if name in os.environ}
    if task_id is not None:
        env["TASK_ID"] = task_id
    out = subprocess.run([sys.executable, str(SCRIPTS / "monitoring_loop.py"),
                          str(n), str(path), "--aspect", aspect],
                         capture_output=True, text=True, env=env, cwd=path.parent)
    return json.loads(out.stdout)


def verify(path: Path) -> tuple[dict, int]:
    run = subprocess.run([sys.executable, str(SCRIPTS / "verify_report.py"), str(path)],
                         capture_output=True, text=True)
    return json.loads(run.stdout), run.returncode


def main() -> int:
    with tempfile.TemporaryDirectory() as root:
        report = Path(root) / "r.md"

        assert loop(report, "task-a")["rows_total"] == 2
        second = loop(report, "task-a")
        assert (second["rows_carried"], second["rows_total"]) == (2, 4)
        # The declared count must follow the whole table, or verify_report rejects the report.
        result, code = verify(report)
        assert code == 0 and result["rows"] == 4, result
        assert "**Task:** task-a" in report.read_text(encoding="utf-8")

        # A different Task must not inherit the report left in the workspace.
        assert loop(report, "task-b")["rows_carried"] == 0
        # A different --aspect writes different columns, so the old rows cannot be reused.
        assert loop(report, "task-b", aspect="all")["rows_carried"] == 0
        # Run by hand, with nothing to identify the run: always start over.
        assert loop(report, None)["rows_carried"] == 0

    print("ok")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
