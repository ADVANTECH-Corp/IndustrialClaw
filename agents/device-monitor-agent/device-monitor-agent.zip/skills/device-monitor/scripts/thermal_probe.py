#!/usr/bin/env python3
"""Probe all thermal zones and GPU temperature, assess overheat risk.

Returns JSON with ok, summary, health, and thermal fields.
"""
from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any


def read_thermal_zones() -> list[dict[str, Any]]:
    zones: list[dict[str, Any]] = []
    for zone in sorted(Path("/sys/class/thermal").glob("thermal_zone*")):
        try:
            temp_file = zone / "temp"
            type_file = zone / "type"
            if not temp_file.exists():
                continue
            zone_type = type_file.read_text(encoding="utf-8").strip() if type_file.exists() else "unknown"
            value_c = float(temp_file.read_text(encoding="utf-8").strip()) / 1000.0
            zones.append({"zone": zone.name, "type": zone_type, "temperature_c": value_c})
        except Exception:
            continue
    return zones


def gpu_temperature() -> float | None:
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=temperature.gpu", "--format=csv,noheader,nounits"],
            check=False, text=True, capture_output=True, timeout=5,
        )
        if result.returncode == 0:
            text = result.stdout.strip().splitlines()[0].strip()
            if text and text != "[N/A]":
                return float(text)
    except Exception:
        pass
    return None


def health(zones: list[dict[str, Any]], gpu_temp: float | None) -> tuple[str, list[str]]:
    all_temps = [z["temperature_c"] for z in zones]
    if gpu_temp is not None:
        all_temps.append(gpu_temp)
    warnings: list[str] = []
    if not all_temps:
        return "unknown", []
    max_t = max(all_temps)
    if max_t >= 90:
        warnings.append(f"CRITICAL: Temperature {max_t} °C exceeds 90 °C threshold.")
        return "critical", warnings
    if max_t >= 75:
        warnings.append(f"Temperature {max_t} °C exceeds 75 °C warning threshold.")
        return "warning", warnings
    return "healthy", warnings


def main() -> None:
    zones = read_thermal_zones()
    gpu_temp = gpu_temperature()
    status, warnings = health(zones, gpu_temp)

    all_temps = [z["temperature_c"] for z in zones]
    if gpu_temp is not None:
        all_temps.append(gpu_temp)

    if all_temps:
        max_t = max(all_temps)
        summary = f"Max temperature {max_t} °C — {status}."
    else:
        summary = "No thermal data available."

    thermal: dict[str, Any] = {
        "zones": zones,
        "gpu_temperature_c": gpu_temp,
        "max_temperature_c": max(all_temps) if all_temps else None,
        "overheat": status == "critical",
    }

    print(json.dumps({
        "ok": status != "unknown",
        "summary": summary,
        "health": status,
        "thermal": thermal,
        "warnings": warnings,
        "errors": [],
    }, indent=2))


if __name__ == "__main__":
    main()
