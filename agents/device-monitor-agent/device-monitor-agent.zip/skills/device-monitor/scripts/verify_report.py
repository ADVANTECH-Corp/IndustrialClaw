#!/usr/bin/env python3
"""Check that a monitoring_loop.py report is a real, complete report.

Usage: verify_report.py <report_path>
Exit 0 = this round counts; exit 1 = it does not. The point is to catch a report that was
truncated, never written, or filled with placeholders instead of measurements -- the Agent
must not be able to call a round successful without one.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

# The report's own header decides how many columns a data row must have -- monitoring_loop.py
# writes a different column set per --aspect, and a checker that hardcodes one of them would
# reject the other three.
HEADER_PREFIX = "| 時間 |"
COUNT_LINE = re.compile(r"^\*\*總執行次數:\*\*\s*(\d+)\s*$")


def data_row_re(columns: int) -> re.Pattern[str]:
    """A data row: `columns` cells, the first a timestamp. The alignment row is not one."""
    return re.compile(
        r"^\|\s*\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}\s*(\|[^|]*){%d}\|\s*$" % (columns - 1))


def emit(ok: bool, summary: str, **extra: object) -> int:
    print(json.dumps({"ok": ok, "summary": summary, "small_model_summary": summary[:80],
                      "warnings": [], "errors": [] if ok else [{"message": summary}], **extra},
                     ensure_ascii=False, indent=2))
    return 0 if ok else 1


def main() -> int:
    if len(sys.argv) < 2 or not sys.argv[1].strip():
        return emit(False, "缺少報告路徑 (Usage: verify_report.py <report_path>)")

    path = Path(sys.argv[1])
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        return emit(False, f"報告讀取失敗: {exc}", report_path=str(path))
    if not text.strip():
        return emit(False, "報告是空的", report_path=str(path))
    header = next((line for line in text.splitlines()
                   if line.strip().startswith(HEADER_PREFIX)), None)
    if header is None:
        return emit(False, "報告缺少監控表格標頭", report_path=str(path))
    columns = len(header.strip().strip("|").split("|"))

    data_row = data_row_re(columns)
    rows = [line for line in text.splitlines() if data_row.match(line.strip())]
    if not rows:
        return emit(False, "報告沒有任何一列採樣資料", report_path=str(path))

    # Every cell of every row must say something. "Unknown" is a legal answer (the sensor was
    # unreadable); a blank cell means the row was written without the measurement.
    for line in rows:
        if any(not cell.strip() for cell in line.strip().strip("|").split("|")):
            return emit(False, f"採樣列有空欄位: {line.strip()}", report_path=str(path))

    declared = next((int(m.group(1)) for m in map(COUNT_LINE.match, text.splitlines()) if m), None)
    if declared is not None and declared != len(rows):
        return emit(False, f"宣告 {declared} 次採樣，表格只有 {len(rows)} 列",
                    report_path=str(path), rows=len(rows), declared=declared)

    return emit(True, f"報告通過檢查，共 {len(rows)} 列採樣", report_path=str(path), rows=len(rows))


if __name__ == "__main__":
    raise SystemExit(main())
