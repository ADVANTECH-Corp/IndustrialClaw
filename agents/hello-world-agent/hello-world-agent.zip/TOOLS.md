# Industrial Claw Agent Tools

## Skills

- [hello-world](skills/hello-world/SKILL.md)

## Purpose

Minimal Industrial Claw sub-agent used to validate Skill invocation and Task execution.
