# Hello World

## Description

A minimal Skill used to verify that Industrial Claw can invoke an installed Skill and execute its script.

Use this Skill when a Task requests a basic execution test or asks to confirm that Skill invocation is working.

## Behavior

Run the bundled script:

```bash
bash skills/hello-world/scripts/hello.sh
```

The script prints a single success message and does not modify system configuration or create background processes.

## Expected Result

```text
Industrial Claw skill executed successfully.
```

## Completion Criteria

The Skill is successful when the script exits with code 0 and prints the expected success message.
