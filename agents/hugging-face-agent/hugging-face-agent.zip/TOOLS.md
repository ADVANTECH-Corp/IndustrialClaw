# hugging-face-agent

## Skills

- `hf-weekly-review`: Bounded, evidence-first seven-day Hugging Face model selection with English summaries and run-bound verification.
- `frontend-design`: Anthropic frontend design guidance and a deterministic, responsive HF report renderer. Read this Skill before running the Task. The renderer applies its reviewed HF-specific design plan before the original build publishes and hashes the outputs.

## Update package

Install all packaged scripts together when updating: the English report renderer, summary prompt, source-data validator, and regression fixtures must agree. Runtime, model, credentials, tasks, source selection, and collection budgets are unchanged.
