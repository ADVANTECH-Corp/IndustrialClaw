# hugging-face-agent

## Skills

- `hf-weekly-review`: Bounded, evidence-first seven-day Hugging Face model selection with Traditional Chinese summaries and run-bound verification.
- `frontend-design`: Anthropic frontend design guidance and a deterministic, responsive HF report renderer. Read this Skill before running the Task. The renderer applies its reviewed HF-specific design plan before the original build publishes and hashes the outputs.

## Update package

This is a delta for the installed hugging-face-agent, not a standalone replacement: existing hf-weekly-review scripts are preserved by update-flat. No runtime, model, credentials, tasks, or source collection settings are changed.
