# HF Seven-Day Model Observatory: two-pass design plan

## Pass 1: purpose and alternatives

Readers are English-speaking developers comparing model uses, intended audiences, and primary-source evidence. This is a public-model selection, not a benchmark ranking. Information completeness is not a performance score, and incomplete searches must remain visible. Report copy and generated summaries are English; source quotes remain verbatim.

Colors: paper #F2F6FA, surface #FFFFFF, ink #172C45, muted #435D78, signal #F7C948, link #125DA8. HF yellow is confined to the header border and categories; the rest supports quiet reading. No decorative gradients or repeated shadow cards.

Typography uses locally available Noto Sans TC, PingFang TC, Microsoft JhengHei, then sans-serif, without external downloads. Model IDs use the same family. Headings use clamp(1.8rem,4vw,3.1rem); body text uses 1rem/1.75. Paragraphs are limited to 72ch and summary blocks to 38em.

Rejected alternative: three equal-height card columns. They crowd long model names and evidence and resemble a generic SaaS template.

Selected alternative: one column of model records, left aligned. Desktop records place identity, category, and sources on the left, with uses and evidence on the right. Mobile records stack into a single column. No numbered decorations suggesting rankings.

Desktop:
[Title / actual seven-day window]
[Search completeness and limitations / expandable run details]
[Category filter / model-name or use search]
[Name / category / source | purpose / audience / selection reason]
[Family variants         | limitations / requirements / original evidence]

Mobile:
[Title / window]
[Limitations / filters]
[Name / category / source]
[Purpose / audience / evidence]

## Pass 2: review and implementation contract

Replace the original dark gold three-column cards with pale blue paper, an HF yellow header border, and asymmetric model records. Concentrate brand cues in the header. Prioritize purposes, evidence, and limitations; keep original statistics and run identifiers in expandable details for verification. No oversized dashboard counts, gradients, ranking hints, or automatic animation.

Use semantic header/main/article, labels, and details. Provide visible focus for controls and links, 44px minimum touch targets, wrapping text, and min-width:0 grid children. Use a single column below 760px and no fixed width at 320px. Respect prefers-reduced-motion. Source links have high contrast and open with noopener noreferrer. Show an explicit empty-filter message and update result counts with aria-live.

Preserve factual data and evidence. Generate HTML before the original build's transactional publication, protected by the receipt. Require this plan and the Skill at build time. Record their hashes and the renderer hash in HTML. Independent verification must re-render the same JSON and compare HTML exactly; a marker alone does not establish design compliance.

## Verification scope

Offline tests cover individual records, multiple categories, empty data, long IDs, HTML escaping, original-validator compatibility, rejection of a different Task identity, and rejection of tampered design HTML. Acceptance preserves source-data verification and checks renderer output. These are not browser screenshots. Actual desktop/mobile rendering, keyboard interaction, and visual accessibility require separate browser checks; disclose unavailable checks.
