"""Apply the reviewed frontend-design plan before HF's existing atomic publication.
Delta dependency: installed hf-weekly-review scripts, intentionally not replaced.
"""
import copy
import hashlib
import html
import importlib
import json
import sys
import tempfile
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
HF = BASE.parent / 'hf-weekly-review' / 'scripts'
sys.path.insert(0, str(HF))
r = importlib.import_module('review')
v = importlib.import_module('verify')

CSS = '''
:root{--paper:#F2F6FA;--surface:#FFFFFF;--ink:#172C45;--muted:#435D78;--signal:#F7C948;--link:#125DA8}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:1rem/1.75 "Noto Sans TC","PingFang TC","Microsoft JhengHei",sans-serif}
header,.shell{max-width:1180px;margin:auto;padding:28px clamp(16px,4vw,48px)}header{border-top:12px solid var(--signal);padding-top:38px}h1{font-size:clamp(1.8rem,4vw,3.1rem);line-height:1.2;letter-spacing:-.035em;margin:0 0 20px}h2{font-size:1.35rem;line-height:1.45;margin:0 0 16px;overflow-wrap:anywhere}p{max-width:72ch;margin:10px 0}a{color:var(--link);text-underline-offset:.2em;overflow-wrap:anywhere}a:focus-visible,input:focus-visible,select:focus-visible,summary:focus-visible{outline:3px solid var(--link);outline-offset:4px}a.source{display:inline-flex;align-items:center;min-height:44px;font-weight:700}
.scope{color:var(--muted);overflow-wrap:anywhere}.warning{border-left:5px solid var(--signal);padding:12px 22px;background:var(--surface);margin:20px 0}.warning ul:empty{display:none}.warning ul{padding-left:20px}details{margin:14px 0}summary{cursor:pointer;min-height:44px;padding:7px 0;color:var(--link)}.audit{overflow-wrap:anywhere;font-size:.9rem}.audit pre{white-space:pre-wrap;font:inherit}.filters{display:flex;flex-wrap:wrap;gap:20px;align-items:end;margin:0 0 18px}.filters label{display:grid;gap:6px;font-weight:700}.filters label:last-child{flex:1;min-width:min(100%,240px)}input,select{font:inherit;min-height:44px;max-width:100%;padding:9px 12px;border:1px solid var(--muted);border-radius:6px;background:white;color:var(--ink)}#result-count{color:var(--muted)}main{display:grid;gap:24px}article{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,2fr);gap:28px;background:var(--surface);padding:28px;border-radius:6px}article>div{min-width:0}.category{display:inline-block;background:var(--signal);color:var(--ink);padding:2px 10px;border-radius:3px;font-size:.9rem}.model-meta{overflow-wrap:anywhere;color:var(--muted);font-size:.9rem}.content p{max-width:38em}.content strong{display:block;font-size:.9rem;color:var(--muted)}.content blockquote{margin:18px 0;padding:12px 18px;background:var(--paper);border-left:3px solid var(--link);overflow-wrap:anywhere}.content blockquote p{margin:0}article[hidden],[hidden]{display:none!important}
@media(max-width:760px){article{grid-template-columns:minmax(0,1fr);gap:12px;padding:20px}.filters{align-items:stretch}.filters label{width:100%}header{padding-top:28px}.scope{font-size:.9rem}}
@media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important;scroll-behavior:auto!important}}
@media print{.filters,#result-count{display:none}body{background:white;color:black}article{break-inside:avoid;border:1px solid #435D78}article[hidden]{display:grid!important}a{color:black}}
'''
JS = '''const c=document.getElementById('cat'),q=document.getElementById('q');function filter(){let n=0;for(const a of document.querySelectorAll('article')){a.hidden=!!((c.value&&a.dataset.category!==c.value)||!a.textContent.toLowerCase().includes(q.value.toLowerCase()));if(!a.hidden)n++;}document.getElementById('result-count').textContent='顯示 '+n+' 個模型';document.getElementById('no-results').hidden=n!==0;}c.addEventListener('change',filter);q.addEventListener('input',filter);filter();'''


def design_hash():
    digest=hashlib.sha256()
    for path in (BASE/'SKILL.md',BASE/'DESIGN.md',Path(__file__)):
        assert path.is_file() and not path.is_symlink(), '缺少設計規範或腳本'
        digest.update(path.read_bytes())
    return digest.hexdigest()


def render(data):
    esc=lambda value:html.escape(str(value),quote=True)
    cards=[]
    for row in data['models']:
        left='<h2>'+esc(row['id'])+'</h2><p class="category">'+esc(row['category'])+'</p>'
        left+='<p class="model-meta">家族：'+esc(row['family'])+'</p><p class="model-meta">首次建立：'+esc(row['created_at'])+'</p>'
        left+='<a class="source" href="'+esc(r.model_url(row['id']))+'" target="_blank" rel="noopener noreferrer">查看模型來源</a>'
        left+='<details><summary>同家族版本連結</summary>'+''.join('<p><a href="'+esc(r.model_url(mid))+'" target="_blank" rel="noopener noreferrer">'+esc(mid)+'</a></p>' for mid in row['variants'])+'</details>'
        fields=(('用途','purpose'),('適用對象','audience'),('入選理由','selection_reason'),('限制','limitations'),('硬體需求','hardware'),('未證實宣稱','unverified_claims'),('授權','license'))
        content=''.join('<p><strong>'+label+'</strong>'+esc(row.get(key,'未知'))+'</p>' for label,key in fields)
        content+='<blockquote><strong>用途原文依據</strong><p>'+esc(row['evidence_quote'])+'</p></blockquote>'
        if row['variant']:
            content+='<p>本項是七日內新上傳的衍生版本，不代表基礎模型於七日內首次發布。</p>'
        cards.append('<article data-id="'+esc(row['id'])+'" data-category="'+esc(row['category'])+'"><div>'+left+'</div><div class="content">'+content+'</div></article>')
    warnings=''.join('<li>'+esc(w)+'</li>' for w in data['warnings'])
    options=''.join('<option>'+esc(c)+'</option>' for c in sorted({x['category'] for x in data['models']}))
    audit='<details class="audit"><summary>執行識別與搜尋統計</summary><p>執行：'+esc(data['task_id'])+'／'+esc(data['run_id'])+'</p><p>模型數：'+str(len(cards))+'</p><pre>'+esc(json.dumps(data['counts'],ensure_ascii=False,indent=2))+'</pre></details>'
    page='<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="frontend-design" content="'+design_hash()+'"><title>Hugging Face 七日精選模型週報</title><style>'+CSS+'</style></head><body>'
    page+='<header><h1>Hugging Face<br>七日模型觀測站</h1><p>先看用途，再核對證據。為開發與部署選型整理本週公開模型。</p><p class="scope">範圍：'+esc(data['window_start'])+' ～ '+esc(data['started_at'])+'</p><div class="warning"><ul>'+warnings+'</ul><p>以資訊完整度與可核對用途為先，人氣僅輔助；並非效能實測或全站最佳排名。模型卡只讀前12000字元。授權以來源標示為準。</p></div>'+audit+'</header>'
    page+='<div class="shell"><div class="filters"><label for="cat">模型分類<select id="cat"><option value="">全部分類</option>'+options+'</select></label><label for="q">搜尋模型名稱或用途<input id="q" type="search" placeholder="例如：語音辨識、模型名稱"></label></div><p id="result-count" role="status" aria-live="polite">顯示 '+str(len(cards))+' 個模型</p>'
    if not cards:
        page+='<p>沒有符合品質門檻的模型；未湊數。請查看上方搜尋限制與執行統計。</p>'
    page+='<p id="no-results" hidden>目前沒有符合篩選的模型。請清空搜尋或選擇全部分類。</p><main aria-label="精選模型">'+''.join(cards)+'</main></div><script>'+JS+'</script></body></html>'
    return page


def check_design(root):
    data=v.load(root/'models.json')
    actual=(root/'report.html').read_text(encoding='utf-8')
    assert actual==render(data), '網頁未套用本版 frontend-design，或內容已被修改'
    return data


def regression(check=False):
    task=r.identity();path=r.OUT/'design-regression.json'
    if check:
        result=v.load(path)
        assert result['ok'] and result['task_id']==task and result['design_hash']==design_hash() and result['checks']>=7
        return result
    t=importlib.import_module('test_review')
    r.OUT.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='hf-design-',dir=r.OUT) as folder:
        root=Path(folder)
        previous=r.render;r.render=render
        try:
            data=t.fixture(root,task)
        finally:
            r.render=previous
        assert v.verify(root,task)['models']==1
        check_design(root)
        t.must_fail(lambda:v.verify(root,'other-task'))
        altered=copy.deepcopy(data);altered['models'][0]['purpose']='<script>alert("x")</script>'
        page=render(altered)
        assert '&lt;script&gt;' in page and '<script>alert(' not in page
        altered['models'][0]['id']='org/'+'x'*200
        assert 'overflow-wrap:anywhere' in render(altered)
        empty=copy.deepcopy(data);empty['models']=[]
        assert '沒有符合品質門檻的模型' in render(empty)
        assert '@media(max-width:760px)' in page and 'prefers-reduced-motion' in page and ':focus-visible' in page
        assert '<script src=' not in page and '<link ' not in page
        (root/'report.html').write_text('tampered',encoding='utf-8')
        t.must_fail(lambda:check_design(root))
    result={'ok':True,'task_id':task,'checks':9,'design_hash':design_hash(),'scope':'offline design, escaping and original verifier compatibility; not browser visual verification'}
    r.save(path,result)
    return result


def main():
    args=sys.argv[1:]
    if args==['build']:
        design_hash()
        regression(True)
        r.render=render
        r.build()
        return {'ok':True,'design':'frontend-design','publication':'original HF transaction'}
    if args in (['test'],['test-check']):
        return regression(args==['test-check'])
    if args in (['verify'],['verify','--final']):
        final='--final' in args
        result=v.verify(r.OUT,r.identity(),final)
        check_design(r.OUT)
        regression(True)
        return {**result,'design':'frontend-design','browser_visual_check':'not performed by this script'}
    raise ValueError('使用 test、test-check、build、verify 或 verify --final')


if __name__=='__main__':
    try:
        print(json.dumps(main(),ensure_ascii=False),flush=True)
    except Exception as exc:
        print('ERROR: frontend-design：'+str(exc)+'；請檢查原 HF Skill、設計檔與本次執行證據。',file=sys.stderr,flush=True)
        sys.exit(1)
