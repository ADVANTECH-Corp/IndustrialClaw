"""Offline regression, not a substitute for a real Task/runtime test."""
import copy
import datetime as dt
import hashlib
import json
import os
import signal
import subprocess
import sys
import tempfile
import time
from pathlib import Path
import review as r
import verify as v


def must_fail(fn):
    try:
        fn()
    except (AssertionError,ValueError,FileNotFoundError,TimeoutError):
        return
    raise AssertionError('應拒絕卻通過')


def fixture(root,task):
    stamp=dt.datetime.now(dt.timezone.utc)
    row={'id':'example/model','created_at':stamp.isoformat(),'pipeline_tag':'text-generation','category':'文字生成','family':'example/model','url':'https://huggingface.co/example/model','license':'未知','metadata_score':2,'variants':['example/model'],'source_metadata':{'createdAt':stamp.isoformat(),'pipeline_tag':'text-generation'},'purpose':'生成繁體中文文字','audience':'文字應用開發者','limitations':'未知','hardware':'未知','unverified_claims':'作者宣稱，未實測','selection_reason':'用途來源可核對','evidence_excerpt':'This model generates multilingual text for applications.','evidence_quote':'This model generates multilingual text','summary_status':'ok','summary_model':r.MODEL,'card_sha256':'0'*64,'variant':False}
    data={'schema_version':2,'task_id':task,'run_id':'a'*32,'started_at':stamp.isoformat(),'window_start':(stamp-dt.timedelta(days=7)).isoformat(),'finished_at':stamp.isoformat(),'state':'complete','time_field':'createdAt','collection_complete':True,'warnings':[],'models':[row],'counts':{'candidates':1,'merged_variants':0,'selected':1}}
    run=root/'runs'/data['run_id'];run.mkdir(parents=True,exist_ok=True)
    r.save(run/'candidates.json',[row]);r.save(run/'selection.json',[row])
    raw=json.dumps(data,ensure_ascii=False);page=r.render(data)
    for base in (root,run):
        r.atomic(base/'models.json',raw);r.atomic(base/'report.html',page)
    receipt={'task_id':task,'run_id':data['run_id'],'finished_at':data['finished_at'],'sha256':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ('models.json','report.html')}}
    r.save(root/'active.json',{'task_id':task,'run_id':data['run_id'],'state':'complete'})
    r.save(root/'receipt.json',receipt)
    return data


def main():
    task=r.identity()
    if sys.argv[1:]==['--check']:
        result=v.load(r.OUT/'regression.json')
        assert result['task_id']==task and result['ok'] and result['checks']>=9
        print(json.dumps(result));return
    assert not sys.argv[1:]
    checks=0
    end=r.date('2026-11-04T00:00:00Z');start=end-dt.timedelta(days=7)
    assert end-start==dt.timedelta(days=7) and start<=r.date('2026-10-28T00:00:00Z')<=end
    assert r.date('2026-10-27T23:59:59Z')<start
    checks+=1
    records=[{'id':'org/model-'+str(i),'family':'org/family-'+str(i),'category':'cat'+str(i%7),'quality_score':10,'metadata_score':2,'downloads':i,'likes':0} for i in range(50)]
    chosen=r.choose(records)
    assert len(chosen)==15 and max(sum(x['category']==c for x in chosen) for c in {x['category'] for x in chosen})<=3
    checks+=1
    duplicate=copy.deepcopy(records[0]);duplicate['id']='org/variant';duplicate['quality_score']=11
    chosen=r.choose([records[0],duplicate]);assert len(chosen)==1
    checks+=1
    assert r.low_info({'id':'org/test-1'},'x'*1000) and r.low_info({'id':'org/model'},'blank')
    checks+=1
    must_fail(lambda:r.model_url('../model'))
    assert not r.allowed('https://evil.example/api/models')
    must_fail(lambda:r.request('https://huggingface.co/api/models',time.monotonic()-1))
    checks+=1
    with tempfile.TemporaryDirectory(prefix='hf-regression-',dir=r.OUT) as folder:
        root=Path(folder);data=fixture(root,task)
        assert v.verify(root,task)['models']==1
        checks+=1
        must_fail(lambda:v.verify(root,'different-task'))
        checks+=1
        (root/'report.html').write_text('tampered',encoding='utf-8')
        must_fail(lambda:v.verify(root,task));fixture(root,task)
        checks+=1
        active=v.load(root/'active.json');active['state']='running';r.save(root/'active.json',active)
        must_fail(lambda:v.verify(root,task));fixture(root,task)
        checks+=1
        data['models'][0]['purpose']='<script>alert("x")</script>'
        page=r.render(data)
        assert '&lt;script&gt;' in page and '<script>alert(' not in page
        checks+=1
        # Exercise the actual SIGTERM handler in a disposable child owned by this test.
        target=root/'late-write.txt'
        code='import signal,time,sys; import review; signal.signal(signal.SIGTERM,review.stopped); print("ready",flush=True); time.sleep(60); open(sys.argv[1],"w").write("late")'
        child=subprocess.Popen([sys.executable,'-u','-c',code,str(target.resolve())],cwd=Path(__file__).parent,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            assert child.stdout.readline().strip()=='ready'
            child.send_signal(signal.SIGTERM)
            child.communicate(timeout=5)
            assert child.returncode==143 and not target.exists()
        finally:
            if child.poll() is None:
                child.kill();child.communicate()
        checks+=1
    r.save(r.OUT/'regression.json',{'task_id':task,'ok':True,'checks':checks,'scope':'offline fixtures and own-child SIGTERM; not platform stop-task integration'})
    print(json.dumps({'ok':True,'checks':checks}),flush=True)


if __name__=='__main__':
    try:
        r.OUT.mkdir(parents=True,exist_ok=True)
        main()
    except Exception as exc:
        print('ERROR: 回歸測試失敗：'+str(exc),file=sys.stderr,flush=True)
        sys.exit(1)
