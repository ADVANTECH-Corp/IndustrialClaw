"""Independent acceptance checks: task identity, final commit, provenance, caps and HTML."""
import collections
import datetime as dt
import hashlib
import json
import os
import re
import sys
from html.parser import HTMLParser
from pathlib import Path

ROOT=Path('outputs/hf-weekly')


def task_identity():
    value=os.environ.get('TASK_ID') or Path(os.environ.get('TASK_ARTIFACT_DIR','')).name
    if not value or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,127}',value):
        raise ValueError('Missing platform run identity')
    return value


def load(path):
    assert path.is_file() and not path.is_symlink(), 'Missing regular file: '+str(path)
    return json.loads(path.read_text(encoding='utf-8'))


def date(text):
    value=dt.datetime.fromisoformat(text.replace('Z','+00:00'))
    assert value.tzinfo is not None, 'Missing timezone'
    return value


class Cards(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.cards={};self.current=None;self.text=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='article':
            mid=a.get('data-id')
            assert mid and mid not in self.cards,'Duplicate HTML cards'
            self.current=mid;self.cards[mid]={'category':a.get('data-category'),'text':[],'links':[]}
        if tag=='a':
            href=a.get('href','')
            assert re.fullmatch(r'https://huggingface\.co/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',href),'Invalid source link'
            assert a.get('target')=='_blank' and {'noopener','noreferrer'}<=set(a.get('rel','').split())
            if self.current:
                self.cards[self.current]['links'].append(href)
    def handle_endtag(self,tag):
        if tag=='article':
            self.current=None
    def handle_data(self,text):
        self.text.append(text)
        if self.current:
            self.cards[self.current]['text'].append(text)


def verify(root,expected_task,final=False):
    active=load(root/'active.json');receipt=load(root/'receipt.json');data=load(root/'models.json')
    for obj in (active,receipt,data):
        assert obj['task_id']==expected_task,'Output does not belong to this Task; stale files are not accepted'
        assert obj['run_id']==data['run_id'],'Outputs from different runs are mixed'
    assert re.fullmatch('[0-9a-f]{32}',data['run_id'])
    assert active['state']==data['state']=='complete','Only a checkpoint exists; the run is incomplete'
    start=date(data['window_start']);end=date(data['started_at']);finished=date(data['finished_at'])
    assert end-start==dt.timedelta(days=7) and end<=finished
    assert finished-end<dt.timedelta(seconds=720),'Task hard limit exceeded'
    assert receipt['finished_at']==data['finished_at']
    assert data['time_field']=='createdAt'
    assert data['collection_complete'] or data['warnings'],'Incomplete search has no warning'
    run=root/'runs'/data['run_id']
    for name in ('models.json','report.html'):
        path=root/name
        assert path.is_file() and not path.is_symlink(),'Expected output is not a regular file'
        raw=path.read_bytes()
        assert hashlib.sha256(raw).hexdigest()==receipt['sha256'][name],'Output was modified or not fully written'
        assert raw==(run/name).read_bytes(),"Published files differ from this run's evidence"
    candidates=load(run/'candidates.json')
    sources={r['id']:r for r in candidates}
    assert len(sources)==len(candidates),'Duplicate candidates'
    counts=data['counts']
    assert counts['candidates']==len(candidates)
    assert counts['merged_variants']==len(candidates)-len({r['family'] for r in candidates})
    selected=load(run/'selection.json')
    selected_ids={r['id'] for r in selected}
    assert len(data['models'])<=15 and counts['selected']==len(data['models'])
    parser=Cards();parser.feed((root/'report.html').read_text(encoding='utf-8'))
    families=set();ids=set();categories=collections.Counter()
    family_members=collections.defaultdict(set)
    for source in candidates:
        family_members[source['family']].add(source['id'])
    for row in data['models']:
        mid=row['id']
        assert mid not in ids and row['family'] not in families,'Duplicate model or family'
        ids.add(mid);families.add(row['family']);categories[row['category']]+=1
        assert mid in sources and mid in selected_ids
        source=sources[mid]
        for field in ('created_at','pipeline_tag','category','family','url','license','metadata_score'):
            assert row[field]==source[field],'Source field differs: '+field
        assert start<=date(row['created_at'])<=end,'Outside the seven-day window'
        assert source['source_metadata']['createdAt']==row['created_at']
        assert source['source_metadata']['pipeline_tag']==row['pipeline_tag']
        assert row['url']=='https://huggingface.co/'+mid
        assert set(row['variants'])==family_members[row['family']]
        quote=row['evidence_quote']
        assert 12<=len(quote)<=500 and quote in row['evidence_excerpt'],'Missing original-source evidence for intended use'
        assert row['summary_status']=='ok' and row['summary_model']
        assert re.fullmatch('[0-9a-f]{64}',row['card_sha256'])
        assert row['purpose'].strip().casefold()!='unknown','Models with unknown purposes cannot be selected'
        for field in ('purpose','audience','limitations','hardware','unverified_claims'):
            assert re.search('[A-Za-z]',row[field]) and not re.search(r'[\u3400-\u9fff]',row[field]), 'Summary must be in English'
        card=parser.cards[mid];visible=''.join(card['text'])
        assert card['category']==row['category']
        for field in ('id','created_at','family','category','purpose','audience','selection_reason','limitations','hardware','unverified_claims','evidence_quote','license'):
            assert isinstance(row[field],str) and row[field] and row[field] in visible,'HTML field differs: '+field
        assert row['url'] in card['links']
        for member in row['variants']:
            assert 'https://huggingface.co/'+member in card['links']
    assert all(n<=3 for n in categories.values()),'More than three models per category'
    assert set(parser.cards)==ids,'HTML cards differ from JSON'
    visible=''.join(parser.text)
    assert 'Model count: '+str(len(ids)) in visible
    assert data['task_id'] in visible and data['run_id'] in visible
    assert data['started_at'] in visible and data['window_start'] in visible
    for warning in data['warnings']:
        assert warning in visible,'Warning is not displayed'
    if not ids:
        assert 'No models met the quality threshold' in visible
    if final:
        tests=load(root/'regression.json')
        assert tests['task_id']==expected_task and tests['ok'] and tests['checks']>=9,'Regression tests did not pass for this run'
    return {'ok':True,'models':len(ids),'final':final,'partial':bool(data['warnings']),'task_id':expected_task}


if __name__=='__main__':
    try:
        if sys.argv[1:] not in ([],['--final']):
            raise ValueError('Unknown argument')
        print(json.dumps(verify(ROOT,task_identity(),'--final' in sys.argv),ensure_ascii=False))
    except Exception as exc:
        print('ERROR: Verification failed: '+str(exc)+"; check this run's active/receipt/checkpoint; do not accept stale files as success.",file=sys.stderr,flush=True)
        sys.exit(1)
