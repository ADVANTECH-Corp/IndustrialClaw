"""Independent acceptance checks: task identity, final commit, provenance, caps and HTML."""
import collections
import datetime as dt
import hashlib
import json
import os
import re
import sys
from html.parser import HTMLParser
from pathlib import Path

ROOT=Path('outputs/hf-weekly')


def task_identity():
    value=os.environ.get('TASK_ID') or Path(os.environ.get('TASK_ARTIFACT_DIR','')).name
    if not value or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,127}',value):
        raise ValueError('缺少平台執行識別')
    return value


def load(path):
    assert path.is_file() and not path.is_symlink(), '缺少正常檔案：'+str(path)
    return json.loads(path.read_text(encoding='utf-8'))


def date(text):
    value=dt.datetime.fromisoformat(text.replace('Z','+00:00'))
    assert value.tzinfo is not None, '缺少時區'
    return value


class Cards(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.cards={};self.current=None;self.text=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='article':
            mid=a.get('data-id')
            assert mid and mid not in self.cards,'網頁卡片重複'
            self.current=mid;self.cards[mid]={'category':a.get('data-category'),'text':[],'links':[]}
        if tag=='a':
            href=a.get('href','')
            assert re.fullmatch(r'https://huggingface\.co/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',href),'不合法來源連結'
            assert a.get('target')=='_blank' and {'noopener','noreferrer'}<=set(a.get('rel','').split())
            if self.current:
                self.cards[self.current]['links'].append(href)
    def handle_endtag(self,tag):
        if tag=='article':
            self.current=None
    def handle_data(self,text):
        self.text.append(text)
        if self.current:
            self.cards[self.current]['text'].append(text)


def verify(root,expected_task,final=False):
    active=load(root/'active.json');receipt=load(root/'receipt.json');data=load(root/'models.json')
    for obj in (active,receipt,data):
        assert obj['task_id']==expected_task,'輸出不屬於本次 Task，舊檔不可驗收'
        assert obj['run_id']==data['run_id'],'不同執行的混合輸出'
    assert re.fullmatch('[0-9a-f]{32}',data['run_id'])
    assert active['state']==data['state']=='complete','只有 checkpoint，尚未完成'
    start=date(data['window_start']);end=date(data['started_at']);finished=date(data['finished_at'])
    assert end-start==dt.timedelta(days=7) and end<=finished
    assert finished-end<dt.timedelta(seconds=720),'超過工作硬上限'
    assert receipt['finished_at']==data['finished_at']
    assert data['time_field']=='createdAt'
    assert data['collection_complete'] or data['warnings'],'不完整搜尋未警告'
    run=root/'runs'/data['run_id']
    for name in ('models.json','report.html'):
        path=root/name
        assert path.is_file() and not path.is_symlink(),'預期輸出不是正常檔案'
        raw=path.read_bytes()
        assert hashlib.sha256(raw).hexdigest()==receipt['sha256'][name],'輸出被修改或未完成寫入'
        assert raw==(run/name).read_bytes(),'發佈檔案與本次執行證據不同'
    candidates=load(run/'candidates.json')
    sources={r['id']:r for r in candidates}
    assert len(sources)==len(candidates),'候選重複'
    counts=data['counts']
    assert counts['candidates']==len(candidates)
    assert counts['merged_variants']==len(candidates)-len({r['family'] for r in candidates})
    selected=load(run/'selection.json')
    selected_ids={r['id'] for r in selected}
    assert len(data['models'])<=15 and counts['selected']==len(data['models'])
    parser=Cards();parser.feed((root/'report.html').read_text(encoding='utf-8'))
    families=set();ids=set();categories=collections.Counter()
    family_members=collections.defaultdict(set)
    for source in candidates:
        family_members[source['family']].add(source['id'])
    for row in data['models']:
        mid=row['id']
        assert mid not in ids and row['family'] not in families,'重複模型或家族'
        ids.add(mid);families.add(row['family']);categories[row['category']]+=1
        assert mid in sources and mid in selected_ids
        source=sources[mid]
        for field in ('created_at','pipeline_tag','category','family','url','license','metadata_score'):
            assert row[field]==source[field],'來源欄位不同：'+field
        assert start<=date(row['created_at'])<=end,'不在七日時窗'
        assert source['source_metadata']['createdAt']==row['created_at']
        assert source['source_metadata']['pipeline_tag']==row['pipeline_tag']
        assert row['url']=='https://huggingface.co/'+mid
        assert set(row['variants'])==family_members[row['family']]
        quote=row['evidence_quote']
        assert 12<=len(quote)<=500 and quote in row['evidence_excerpt'],'缺用途原文依據'
        assert row['summary_status']=='ok' and row['summary_model']
        assert re.fullmatch('[0-9a-f]{64}',row['card_sha256'])
        assert row['purpose']!='未知','用途不明不得入選'
        card=parser.cards[mid];visible=''.join(card['text'])
        assert card['category']==row['category']
        for field in ('id','created_at','family','category','purpose','audience','selection_reason','limitations','hardware','unverified_claims','evidence_quote','license'):
            assert isinstance(row[field],str) and row[field] and row[field] in visible,'網頁欄位不同：'+field
        assert row['url'] in card['links']
        for member in row['variants']:
            assert 'https://huggingface.co/'+member in card['links']
    assert all(n<=3 for n in categories.values()),'每類超過三個'
    assert set(parser.cards)==ids,'卡片數與JSON不同'
    visible=''.join(parser.text)
    assert '模型數：'+str(len(ids)) in visible
    assert data['task_id'] in visible and data['run_id'] in visible
    assert data['started_at'] in visible and data['window_start'] in visible
    for warning in data['warnings']:
        assert warning in visible,'警告未顯示'
    if not ids:
        assert '沒有符合品質門檻的模型' in visible
    if final:
        tests=load(root/'regression.json')
        assert tests['task_id']==expected_task and tests['ok'] and tests['checks']>=9,'本次回歸測試未通過'
    return {'ok':True,'models':len(ids),'final':final,'partial':bool(data['warnings']),'task_id':expected_task}


if __name__=='__main__':
    try:
        if sys.argv[1:] not in ([],['--final']):
            raise ValueError('未知參數')
        print(json.dumps(verify(ROOT,task_identity(),'--final' in sys.argv),ensure_ascii=False))
    except Exception as exc:
        print('ERROR: 驗收失敗：'+str(exc)+'；請核對本次 active/receipt/checkpoint，勿將舊檔當成功。',file=sys.stderr,flush=True)
        sys.exit(1)
