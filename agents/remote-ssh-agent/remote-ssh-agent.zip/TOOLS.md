# SSH Agent Tools

This package provides one Skills for `remote-ssh-agent`:

- `gen-ssh-key`: generate a new passphrase-less SSH key for every Task run, install its public key using the bootstrap password, and verify BatchMode login.

## Skills

- [gen-ssh-key](skills/gen-ssh-key/SKILL.md)

## Required bootstrap material

`materials/ssh_password.txt` contains only the initial SSH credential, not a fixed private key:

```text
host: <remote host or IP>
username: <remote SSH username>
password: <bootstrap password>
```

Host, username, and password are read exclusively from this material; the Skill has no host or username fallback. Each Task generates a fresh private key under `/tmp` for its Run ID. The password is supplied to OpenSSH through a temporary `SSH_ASKPASS` helper, never through a command argument or terminal prompt. After public-key installation, all verification and Isaac operations use the new key with `BatchMode=yes`.


## Execution rules

1. Never log the password or private key.
2. Never require a pre-generated key in `materials/`.
3. Generate a fresh key for every Run ID; do not overwrite another run's key.
4. Use `ConnectTimeout=10`, a temporary known-hosts file, and `StrictHostKeyChecking=accept-new` on every SSH/SCP call.
5. Stop immediately if public-key installation or BatchMode verification fails.
