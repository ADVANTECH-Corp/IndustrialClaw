---
name: gen-ssh-key
description: Establish a passwordless SSH connection from materials/ssh_password.txt. Use this whenever a Task asks to connect to a remote computer using that material; the Skill internally creates a run ID and fresh key, installs it, verifies BatchMode login, and records the active run.
---

# Establish SSH Connection

Use this Skill when the Task asks to connect to the remote computer using `materials/ssh_password.txt`. Do not require the Task to describe key generation or provide an `execute` command.

## Required material

`materials/ssh_password.txt`:

```text
host: <remote host or IP>
username: <remote SSH username>
password: <bootstrap password>
```

## Execute

Run exactly:

```bash
bash ./skills/gen-ssh-key/setup_ssh_key.sh
```

No `RUN_ID` or output argument is required. The script owns the complete bootstrap workflow:

1. Parse host, username, and password only from the material.
2. Create a unique Run ID and publish it to `outputs/ssh/.current-run-id`.
3. Generate a fresh passphrase-less Ed25519 key under `/tmp/ssh-<RUN_ID>/`.
4. Install the public key with a temporary non-interactive `SSH_ASKPASS` helper.
5. Verify the new key with `BatchMode=yes`.
6. Write `outputs/ssh/<RUN_ID>/ssh-key-setup-report.md` without secrets.

A caller may set `RUN_ID` or pass a results root only for controlled reuse, but ordinary Tasks should not do so. Any parsing, installation, or verification failure returns non-zero. Never print the password or private key.

