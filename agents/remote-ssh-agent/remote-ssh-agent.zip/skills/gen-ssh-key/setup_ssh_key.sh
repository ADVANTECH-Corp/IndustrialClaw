#!/usr/bin/env bash
set -euo pipefail

D="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${D}/config.sh"

RESULTS_ROOT="${1:-${RESULTS_ROOT_DEFAULT}}"
RUN_ID="${RUN_ID:-$(date +%Y%m%d-%H%M%S)-$$}"
OUTPUT_DIR="${RESULTS_ROOT}/${RUN_ID}"
CURRENT_RUN_FILE="${RESULTS_ROOT}/.current-run-id"
REPORT_PATH="${OUTPUT_DIR}/ssh-key-setup-report.md"
KEY_DIR="/tmp/isaac-ssh-${RUN_ID}"
KEY_FILE="${KEY_DIR}/id_ed25519"
KNOWN_HOSTS_FILE="${KEY_DIR}/known_hosts"
ASKPASS_FILE="${KEY_DIR}/askpass.sh"

fail() { printf '[gen-ssh-key][ERROR] %s\n' "$*" >&2; exit 1; }
trim() { local v="$1"; v="${v#"${v%%[![:space:]]*}"}"; v="${v%"${v##*[![:space:]]}"}"; printf '%s' "$v"; }
cleanup() { unset OPENCLAW_SSH_PASSWORD SSH_ASKPASS SSH_ASKPASS_REQUIRE 2>/dev/null || true; rm -f "${ASKPASS_FILE}"; }
trap cleanup EXIT

case "${SSH_HOST_KEY_CHECKING}" in accept-new|yes) ;; *) fail "SSH_HOST_KEY_CHECKING must be accept-new or yes" ;; esac
[[ "${CONNECT_TIMEOUT_SECONDS}" =~ ^[0-9]+$ ]] || fail "CONNECT_TIMEOUT_SECONDS must be an integer"
[[ "${INSTALL_TIMEOUT_SECONDS}" =~ ^[0-9]+$ ]] || fail "INSTALL_TIMEOUT_SECONDS must be an integer"
[[ "${RUN_ID}" =~ ^[A-Za-z0-9._-]+$ ]] || fail "RUN_ID contains unsupported characters"
[ -f "${SSH_MATERIAL}" ] || fail "bootstrap SSH credential is missing: ${SSH_MATERIAL}"

REMOTE_HOST=""
REMOTE_USER=""
REMOTE_PASSWORD=""
while IFS=: read -r raw_key raw_value; do
  key="$(trim "${raw_key}")"
  value="$(trim "${raw_value}")"
  case "${key,,}" in
    host|hostname|ip) REMOTE_HOST="${value}" ;;
    username|user|login) REMOTE_USER="${value}" ;;
    password|passwd|pass) REMOTE_PASSWORD="${value}" ;;
  esac
done < "${SSH_MATERIAL}"
[ -n "${REMOTE_HOST}" ] || fail "bootstrap material has no host"
[ -n "${REMOTE_USER}" ] || fail "bootstrap material has no username"
[ -n "${REMOTE_PASSWORD}" ] || fail "bootstrap material has no password"
REMOTE="${REMOTE_USER}@${REMOTE_HOST}"

mkdir -p "${OUTPUT_DIR}"
[ ! -e "${KEY_DIR}" ] || fail "run key directory already exists: ${KEY_DIR}"
mkdir -m 700 "${KEY_DIR}"
: > "${KNOWN_HOSTS_FILE}"
chmod 600 "${KNOWN_HOSTS_FILE}"
ssh-keygen -q -t ed25519 -C "openclaw-${RUN_ID}" -f "${KEY_FILE}" -N ""
chmod 600 "${KEY_FILE}"

cat > "${ASKPASS_FILE}" <<'EOF'
#!/usr/bin/env bash
printf '%s\n' "${OPENCLAW_SSH_PASSWORD:?}"
EOF
chmod 700 "${ASKPASS_FILE}"

public_key="$(cat "${KEY_FILE}.pub")"
escaped_key="${public_key//\'/\'\\\'\'}"
remote_command="umask 077; mkdir -p ~/.ssh; touch ~/.ssh/authorized_keys; grep -qxF '${escaped_key}' ~/.ssh/authorized_keys || printf '%s\\n' '${escaped_key}' >> ~/.ssh/authorized_keys; chmod 700 ~/.ssh; chmod 600 ~/.ssh/authorized_keys"

export OPENCLAW_SSH_PASSWORD="${REMOTE_PASSWORD}"
export SSH_ASKPASS="${ASKPASS_FILE}"
export SSH_ASKPASS_REQUIRE=force
export DISPLAY="${DISPLAY:-openclaw-askpass:0}"

set +e
setsid timeout "${INSTALL_TIMEOUT_SECONDS}" ssh \
  -o NumberOfPasswordPrompts=1 \
  -o PreferredAuthentications=password,keyboard-interactive \
  -o PubkeyAuthentication=no \
  -o ConnectTimeout="${CONNECT_TIMEOUT_SECONDS}" \
  -o UserKnownHostsFile="${KNOWN_HOSTS_FILE}" \
  -o StrictHostKeyChecking="${SSH_HOST_KEY_CHECKING}" \
  "${REMOTE}" "${remote_command}" </dev/null
install_rc=$?
set -e
unset OPENCLAW_SSH_PASSWORD SSH_ASKPASS SSH_ASKPASS_REQUIRE
rm -f "${ASKPASS_FILE}"
[ "${install_rc}" -eq 0 ] || fail "public-key installation failed for ${REMOTE} (exit ${install_rc})"

SSH_ARGS=(
  -i "${KEY_FILE}"
  -o IdentitiesOnly=yes
  -o BatchMode=yes
  -o ConnectTimeout="${CONNECT_TIMEOUT_SECONDS}"
  -o UserKnownHostsFile="${KNOWN_HOSTS_FILE}"
  -o StrictHostKeyChecking="${SSH_HOST_KEY_CHECKING}"
)
verification="$(ssh "${SSH_ARGS[@]}" "${REMOTE}" "printf SSH_OK" 2>/dev/null)" || fail "new key failed BatchMode verification for ${REMOTE}"
[ "${verification}" = SSH_OK ] || fail "unexpected verification response from ${REMOTE}"

fingerprint="$(ssh-keygen -lf "${KEY_FILE}.pub" | awk '{print $2}')"
cat > "${REPORT_PATH}" <<EOF
# SSH Key Setup Report

- Run ID: ${RUN_ID}
- Generated key path: ${KEY_FILE}
- Fingerprint: ${fingerprint}
- Remote target: ${REMOTE}
- Public key installation: yes (SSH_ASKPASS bootstrap)
- BatchMode passwordless SSH verification: yes
EOF
printf '%s\n' "${RUN_ID}" > "${CURRENT_RUN_FILE}.tmp"
mv "${CURRENT_RUN_FILE}.tmp" "${CURRENT_RUN_FILE}"
printf '%s\n' "${REPORT_PATH}"
